// src/server.js
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GeminiService } from './services/GeminiService.js';
import { StateStore } from './services/StateStore.js';
import { AgentOrchestrator } from './agents/AgentOrchestrator.js';
import { parseRawMessages, parseSingleMessageBlock } from './services/MessageParser.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT_DIR, 'public');
const SAMPLE_DIR = path.join(ROOT_DIR, 'sample_data');

// Load environment variables from .env if present
function loadEnv() {
  const envPath = path.join(ROOT_DIR, '.env');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf-8').split('\n');
    lines.forEach(l => {
      const match = l.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
      if (match) {
        const key = match[1];
        let val = match[2] || '';
        val = val.trim().replace(/^['"]|['"]$/g, '');
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    });
  }
}

loadEnv();

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';

// Services
const geminiService = new GeminiService(process.env.GEMINI_API_KEY || '', process.env.MODEL_NAME || 'gemini-2.0-flash');
const stateStore = new StateStore();
const orchestrator = new AgentOrchestrator(geminiService, stateStore);

// MIME types for static files
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 10 * 1024 * 1024) {
        // 10MB limit
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        if (!body.trim()) return resolve({});
        const json = JSON.parse(body);
        resolve(json);
      } catch (err) {
        resolve({ rawText: body });
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  try {
    // -------------------------------------------------------------
    // API ROUTES
    // -------------------------------------------------------------

    // 1. GET /api/status
    if (req.method === 'GET' && pathname === '/api/status') {
      return sendJson(res, 200, {
        status: 'online',
        hasGeminiKey: geminiService.hasValidKey(),
        model: geminiService.modelName,
        totalModelCalls: stateStore.callCounter,
        totalTokens: stateStore.getTotalTokens()
      });
    }

    // 2. POST /api/settings
    if (req.method === 'POST' && pathname === '/api/settings') {
      const body = await parseBody(req);
      if (body.apiKey !== undefined) {
        geminiService.setApiKey(body.apiKey);
      }
      if (body.modelName) {
        geminiService.setModelName(body.modelName);
      }
      return sendJson(res, 200, {
        success: true,
        message: 'Settings updated successfully',
        hasGeminiKey: geminiService.hasValidKey(),
        model: geminiService.modelName
      });
    }

    // 3. POST /api/reset
    if (req.method === 'POST' && pathname === '/api/reset') {
      stateStore.reset();
      return sendJson(res, 200, {
        success: true,
        message: 'Planner state reset successfully',
        state: stateStore.getStateSummary()
      });
    }

    // 4. GET /api/sample/:pack
    if (req.method === 'GET' && pathname.startsWith('/api/sample/')) {
      const packId = pathname.replace('/api/sample/', '').trim();
      const fileName = packId === '2' ? 'hackathon_messages_pack2.txt' : 'hackathon_messages_pack1.txt';
      const filePath = path.join(SAMPLE_DIR, fileName);
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf-8');
        return sendJson(res, 200, { success: true, pack: packId, content });
      }
      return sendJson(res, 404, { success: false, error: 'Sample pack not found' });
    }

    // 5. GET /api/dynamic-presets
    if (req.method === 'GET' && pathname === '/api/dynamic-presets') {
      const presetsPath = path.join(SAMPLE_DIR, 'dynamic_update_test_cases.json');
      if (fs.existsSync(presetsPath)) {
        const presets = JSON.parse(fs.readFileSync(presetsPath, 'utf-8'));
        return sendJson(res, 200, { success: true, presets });
      }
      return sendJson(res, 200, { success: true, presets: [] });
    }

    // 6. POST /api/process-batch
    if (req.method === 'POST' && pathname === '/api/process-batch') {
      const body = await parseBody(req);
      let rawText = body.text || '';

      if (body.samplePack) {
        const fileName = body.samplePack === 2 ? 'hackathon_messages_pack2.txt' : 'hackathon_messages_pack1.txt';
        const filePath = path.join(SAMPLE_DIR, fileName);
        if (fs.existsSync(filePath)) {
          rawText = fs.readFileSync(filePath, 'utf-8');
        }
      }

      if (!rawText.trim()) {
        return sendJson(res, 400, { success: false, error: 'No text or file content provided.' });
      }

      // Reset previous state before full batch run
      stateStore.reset();

      // Parse messages
      const parsedMessages = parseRawMessages(rawText);
      if (parsedMessages.length === 0) {
        return sendJson(res, 400, { success: false, error: 'Could not extract valid messages from the input file.' });
      }

      // Run multi-agent orchestrator
      const summary = await orchestrator.processAllMessages(parsedMessages);

      return sendJson(res, 200, {
        success: true,
        messageCount: parsedMessages.length,
        summary
      });
    }

    // 7. POST /api/message/add
    if (req.method === 'POST' && pathname === '/api/message/add') {
      const body = await parseBody(req);
      const text = body.content || body.text || '';
      if (!text.trim()) {
        return sendJson(res, 400, { success: false, error: 'Message content cannot be empty.' });
      }

      const nextNum = stateStore.messages.length + 1;
      const parsedMsg = parseSingleMessageBlock(text, nextNum);
      if (body.sender) parsedMsg.sender = body.sender;
      if (body.date) parsedMsg.date = body.date;

      const updateResult = await orchestrator.processNewMessage(parsedMsg);
      return sendJson(res, 200, updateResult);
    }

    // 8. GET /api/state
    if (req.method === 'GET' && pathname === '/api/state') {
      return sendJson(res, 200, stateStore.getStateSummary());
    }

    // 9. GET /api/export/plan
    if (req.method === 'GET' && pathname === '/api/export/plan') {
      const summary = stateStore.getStateSummary();
      const planMarkdown = generatePlanMarkdown(summary);
      res.writeHead(200, {
        'Content-Type': 'text/markdown; charset=utf-8',
        'Content-Disposition': 'attachment; filename="Mind_to_Machine_Hackathon_Plan.md"'
      });
      return res.end(planMarkdown);
    }

    // 10. GET /api/export/trace
    if (req.method === 'GET' && pathname === '/api/export/trace') {
      const traceData = {
        eventName: 'Mind to Machine Hackathon Plan & Execution Trace',
        exportedAt: new Date().toISOString(),
        totalModelCalls: stateStore.callCounter,
        totalTokenUsage: stateStore.getTotalTokens(),
        rejectedMessages: stateStore.rejectedMessages,
        conflicts: stateStore.conflicts,
        executionTraces: stateStore.modelTraces
      };
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': 'attachment; filename="AI_Model_Execution_Trace.json"'
      });
      return res.end(JSON.stringify(traceData, null, 2));
    }

    // -------------------------------------------------------------
    // STATIC FILE SERVING
    // -------------------------------------------------------------
    let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

    // Prevent directory traversal
    if (!filePath.startsWith(PUBLIC_DIR)) {
      res.writeHead(403);
      return res.end('Access Denied');
    }

    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const contentType = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': contentType });
      return fs.createReadStream(filePath).pipe(res);
    }

    // Fallback to index.html for SPA routes
    const indexPath = path.join(PUBLIC_DIR, 'index.html');
    if (fs.existsSync(indexPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(indexPath).pipe(res);
    }

    res.writeHead(404);
    res.end('Not Found');
  } catch (err) {
    console.error('[Server Error]', err);
    sendJson(res, 500, { success: false, error: err.message });
  }
});

function generatePlanMarkdown(summary) {
  const p = summary.plan;
  const m = summary.metadata;
  const b = p.budget;
  const v = p.venue;
  const s = p.schedule;
  const f = p.food;
  const j = p.judging;

  return `# Mind to Machine Hackathon - Operational Event Plan
**Location:** ${m.location}
**Total Participants:** ${m.targetParticipants} students (${m.targetTeams} teams)
**Total Headcount to Accommodate & Feed:** ${m.totalHeadcount} persons
**Overall Plan Validity:** ${summary.overallValidity.status}

---

## 1. Venue Allocation
- **Recommended Venue:** ${v.recommended || 'None'}
- **Seating Capacity:** ${v.seatingCapacity} seats
- **Rental Price:** ${v.rentalPrice?.toLocaleString()} PKR
- **Generator Backup:** ${v.generatorAvailable ? 'Yes (Mandatory backup confirmed)' : 'No'}
- **Selection Rationale:** ${v.reason}

---

## 2. Schedule (4-Hour Duration)
- **Time Window:** ${s.startTime} - ${s.endTime} (${s.durationHours} Hours)
- **Prayer Break:** ${s.prayerBreakTime || 'None'}
- **Code Freeze:** ${s.codeFreezeTime || 'None'}
- **Judging Window:** ${s.judgingWindow || 'None'}

### Timeline Breakdown
${(s.timeline || []).map(t => `- **${t.startTime} - ${t.endTime} (${t.durationMinutes}m):** ${t.phase} - ${t.description}`).join('\n')}

---

## 3. Catering & Food
- **Attendees to Feed:** ${f.headcountToFeed} persons (150 students + mentors & judges)
- **Boxes Ordered:** ${f.orderQuantity} boxes (Under-catering strictly prohibited)
- **Meal Package:** ${f.selectedMeal}
- **Price per Person:** ${f.pricePerPerson} PKR
- **Delivery Charges:** ${f.deliveryCharges?.toLocaleString()} PKR
- **Total Catering Cost:** ${f.totalFoodCost?.toLocaleString()} PKR

---

## 4. Judging & Capacity Allocation
- **Total Teams:** ${j.totalTeams}
- **Time per Team:** ${j.timeRequiredPerTeam} minutes
- **Available Judges:** ${j.availableJudges}
- **Required Judges:** ${j.requiredJudges}
- **Capacity Feasibility:** ${j.isCapacitySufficient ? 'SUFFICIENT' : 'ALERT: Insufficient Capacity'}
- **Honorarium:** ${j.totalHonorarium?.toLocaleString()} PKR (${j.honorariumPerJudge} PKR / judge)

### Judge Allocation
${(j.allocation || []).map(a => `- **Judge ${a.judgeNumber} (${a.judgeName}):** ${a.assignedTeamRange} (${a.assignedTeamCount} teams, ~${a.estimatedTimeMinutes} mins)`).join('\n')}

---

## 5. Financials & Budget Breakdown
- **Approved Budget Limit:** ${b.totalApprovedBudget?.toLocaleString()} PKR
- **Total Projected Expenditure:** ${b.totalExpenditure?.toLocaleString()} PKR
- **Remaining Balance:** ${b.remainingBudget?.toLocaleString()} PKR
- **Budget Utilization:** ${b.utilizationPercentage}%
- **Financial Status:** ${b.isWithinBudget ? 'APPROVED & BALANCED' : 'DEFICIT / OVER BUDGET'}

### Line Items
${(b.lineItems || []).map(l => `- **${l.item}:** ${l.cost?.toLocaleString()} PKR (${l.notes})`).join('\n')}

---
*Generated by Mind to Machine AI Operations Planning Agent*
`;
}

// Only auto-listen if run directly
if (process.env.NODE_ENV !== 'test') {
  server.listen(PORT, HOST, () => {
    console.log(`[Mind to Machine Server] Running at http://localhost:${PORT}`);
  });
}

export { server, geminiService, stateStore, orchestrator };
