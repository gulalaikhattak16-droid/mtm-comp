// src/services/StateStore.js

export class StateStore {
  constructor() {
    this.reset();
  }

  reset() {
    this.messages = [];
    this.facts = [];
    this.conflicts = [];
    this.rejectedMessages = [];
    this.modelTraces = [];
    this.callCounter = 0;
    
    // Core event metadata
    this.metadata = {
      eventName: 'Mind to Machine Hackathon',
      location: 'Islamabad',
      targetParticipants: 150,
      targetTeams: 50,
      targetDurationHours: 4,
      organizersCount: 0,
      totalHeadcount: 150
    };

    // The five plan domains
    this.plan = {
      venue: {
        status: 'pending',
        recommended: null,
        options: [],
        reason: 'Awaiting venue proposals from messages.',
        hasGenerator: false,
        capacity: 0,
        rentalCost: 0
      },
      schedule: {
        status: 'pending',
        startTime: '13:00',
        endTime: '17:00',
        durationHours: 4,
        timeline: [],
        prayerBreak: null,
        codeFreeze: null,
        judgingWindow: null,
        constraintsRespected: true,
        notes: ''
      },
      food: {
        status: 'pending',
        headcountToFeed: 150,
        mealOptions: [],
        selectedMeal: null,
        pricePerPerson: 0,
        deliveryFee: 0,
        totalFoodCost: 0,
        orderQuantity: 150,
        enforceMinimumMet: true,
        notes: ''
      },
      judging: {
        status: 'pending',
        totalTeams: 50,
        timePerTeamMinutes: 5,
        judgingWindowMinutes: 45,
        maxTeamsPerJudge: 10,
        requiredJudges: 5,
        availableJudges: 0,
        judgeList: [],
        honorariumPerJudge: 5000,
        totalHonorarium: 0,
        isCapacitySufficient: false,
        allocation: [],
        notes: ''
      },
      budget: {
        status: 'pending',
        totalApprovedBudget: 0,
        totalExpenditure: 0,
        remainingBudget: 0,
        utilizationPercentage: 0,
        breakdown: {
          venue: 0,
          food: 0,
          judgesHonorarium: 0,
          prizes: 0,
          internet: 0,
          printing: 0,
          other: 0
        },
        isValid: false,
        notes: ''
      }
    };

    this.overallValidity = {
      isValid: false,
      status: 'NOT_GENERATED', // NOT_GENERATED, VALID, INVALID, WARNING
      errors: [],
      warnings: []
    };
  }

  addMessage(message) {
    const existingIdx = this.messages.findIndex(m => m.id === message.id);
    if (existingIdx >= 0) {
      this.messages[existingIdx] = { ...this.messages[existingIdx], ...message };
    } else {
      this.messages.push(message);
    }
  }

  recordTrace({ model, areaTag, input, output, inputTokens, outputTokens, totalTokens, isLiveApi, note }) {
    this.callCounter += 1;
    const traceEntry = {
      callNumber: this.callCounter,
      timestamp: new Date().toISOString(),
      model,
      areaTag, // reading, venue, schedule, food, judging, budget
      input,
      output,
      inputTokens: Number(inputTokens) || 0,
      outputTokens: Number(outputTokens) || 0,
      totalTokens: Number(totalTokens) || (Number(inputTokens) + Number(outputTokens)),
      isLiveApi: Boolean(isLiveApi),
      note: note || ''
    };
    this.modelTraces.push(traceEntry);
    return traceEntry;
  }

  recordConflict({ messageId, type, description, attemptedChange, resolution, rejected = false, reason = '' }) {
    const conflict = {
      id: `conf-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
      messageId,
      type,
      description,
      attemptedChange,
      resolution,
      rejected,
      reason
    };
    this.conflicts.push(conflict);

    if (rejected) {
      this.rejectedMessages.push({
        messageId,
        reason,
        timestamp: new Date().toISOString(),
        details: attemptedChange
      });
    }

    return conflict;
  }

  getTotalTokens() {
    return this.modelTraces.reduce((acc, t) => {
      acc.inputTokens += t.inputTokens;
      acc.outputTokens += t.outputTokens;
      acc.totalTokens += t.totalTokens;
      return acc;
    }, { inputTokens: 0, outputTokens: 0, totalTokens: 0 });
  }

  getStateSummary() {
    return {
      metadata: this.metadata,
      messages: this.messages,
      plan: this.plan,
      overallValidity: this.overallValidity,
      conflicts: this.conflicts,
      rejectedMessages: this.rejectedMessages,
      modelTraces: this.modelTraces,
      tokenUsage: this.getTotalTokens(),
      totalModelCalls: this.callCounter
    };
  }
}
