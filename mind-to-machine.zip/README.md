# Mind to Machine — AI Hackathon Planning Agent

A modern, production-ready AI-powered operations dashboard for the **Mind to Machine Hackathon** challenge in Islamabad. The application ingests heterogeneous messages (emails, WhatsApp communications, executive notices) in **English and Roman Urdu**, resolves conflicts and outdated quotes, computes deterministic domain constraints (budget, catering headcounts, judge allocations, and 4-hour schedules), and displays an end-to-end execution audit trace with exact token counts.

---

## 🌟 Key Features

1. **Multi-Agent Architecture**:
   - **Reading Agent**: Extracts facts, numerical values (PKR, seats, times), raw quotes, and message IDs from English & Roman Urdu messages.
   - **Venue Agent**: Evaluates candidate venues, enforces seating capacity ($\ge 150 \text{ students} + \text{staff}$) and mandatory industrial generator backup against Islamabad load shedding.
   - **Schedule Agent**: Creates a strict 4-hour (240-minute) timeline with opening, coding sprints, Zuhr/Asr prayer breaks, strict code freeze, project testing buffer, and final judging tracks.
   - **Food & Catering Agent**: Computes catering requirements for 100% of headcount (150 students + staff + judges). Strictly forbids under-catering orders. Resolves outdated vendor quotes.
   - **Judging Agent**: Computes required judges based on 50 teams, evaluation duration per team, maximum teams per judge, and judging session window. Generates parallel track assignments.
   - **Budget Agent**: Itemizes expenses across 7 categories (Venue, Food, Honorarium, Prizes, Internet, Printing, Contingency), validates solvency against approved ceilings, and rejects over-budget additions.
   - **Conflict Resolver**: Detects overrides, identifies conflicting constraints, preserves existing plan validity, and logs rejections with explicit justifications.

2. **Mandatory AI Execution Trace**:
   - Sequential call numbering (#1, #2, #3, ...)
   - Area tags (`reading`, `venue`, `schedule`, `food`, `judging`, `budget`)
   - Exact input prompt token counts and output candidate token counts directly from actual Gemini API metadata (or deterministic BPE tokenizer)
   - Interactive prompt & model output inspector modal
   - Conflict & rejection audit logs

3. **Dynamic Updates (<= 5 Model Calls)**:
   - Incremental single message submission
   - Selective invocation of affected agents only (e.g. food price update only triggers Food & Budget agents)
   - Real-time plan update without re-running unaffected domains

4. **Bilingual NLP Support**:
   - Fully parses English and Roman Urdu messages (e.g., *"Biryani walay ne rate barha diya hai"*, *"generator kharab hai"*, *"pesay bachanay k liye sirf 100 boxes mangwao"*).

5. **Downloadable Deliverables**:
   - One-click export of complete **Operational Event Plan** (`.md`)
   - One-click export of full **AI Model Execution Trace & Token Telemetry** (`.json`)

---

## 📁 Project Architecture

```
mind-to-machine/
├── package.json                   # Project metadata & npm scripts
├── .env.example                   # Environment configuration template
├── README.md                      # Complete system documentation
├── sample_data/
│   ├── hackathon_messages_pack1.txt   # 12-message dataset with conflicts, Roman Urdu & constraints
│   ├── hackathon_messages_pack2.txt   # Alternate dataset (evening slot, 400k PKR budget, 6 judges)
│   └── dynamic_update_test_cases.json # Pre-built update messages for 1-click UI testing
├── src/
│   ├── server.js                  # Native Node.js HTTP REST server and static host
│   ├── agents/
│   │   ├── ReadingAgent.js        # Bilingual entity & fact extractor
│   │   ├── VenueAgent.js          # Venue capacity & generator validator
│   │   ├── ScheduleAgent.js       # 4-hour milestone timeline planner
│   │   ├── FoodAgent.js           # Headcount & catering arithmetic engine
│   │   ├── JudgingAgent.js        # Judge capacity & workload allocator
│   │   ├── BudgetAgent.js         # Financial breakdown & solvency validator
│   │   ├── ConflictResolver.js    # Contradiction & constraint guard
│   │   └── AgentOrchestrator.js   # Multi-agent coordinator (batch & dynamic <=5 calls)
│   ├── services/
│   │   ├── GeminiService.js       # Live Google Gemini API client with usageMetadata
│   │   ├── TokenCounter.js        # Deterministic BPE subword token counter
│   │   ├── MessageParser.js       # Multi-format message parser
│   │   └── StateStore.js          # Centralized thread-safe plan & telemetry store
│   └── types/
│       └── index.d.ts             # Complete TypeScript interface definitions
├── public/
│   ├── index.html                 # Modern Tailwind dark-mode web dashboard
│   ├── css/
│   │   └── styles.css             # Glassmorphism, animations & dark SaaS theme
│   └── js/
│       ├── icons.js               # Standalone SVG icon library
│       └── app.js                 # Complete React operations application
└── test/
    └── planner.test.js            # Node test suite validating all agent constraints
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js v18+ (Node.js v24 recommended)

### Installation & Setup

1. Open a terminal and navigate to the project directory:
   ```bash
   cd "C:\Users\GULALAI KHATTAK\.gemini\antigravity\scratch\mind-to-machine"
   ```

2. (Optional) Configure your Google Gemini API Key:
   Copy `.env.example` to `.env` and add your API key:
   ```env
   PORT=3000
   GEMINI_API_KEY=your_gemini_api_key_here
   MODEL_NAME=gemini-2.0-flash
   ```
   *Note: If no API key is supplied, the application automatically uses its built-in Deterministic NLP Agent Engine with exact token counting.*

3. Start the application server:
   ```bash
   npm start
   ```
   *(Or run directly: `node src/server.js`)*

4. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

---

## 🧪 Running Unit Tests

Run the deterministic test suite:
```bash
npm test
```
*(Or: `node --test test/planner.test.js`)*

The test suite validates:
- Message parsing and Roman Urdu detection
- Selection of **Islamabad Convention Hall B** over disqualified candidates
- Prevention of under-catering (strictly ordering 167 boxes for 150 students + 12 staff + 5 judges)
- 4-hour timeline verification
- 50-team judging feasibility
- Financial solvency against approved budget ceilings
- Dynamic update conflict rejection and targeted model call bounds

---

## 🎯 How to Use the Dashboard

1. **Batch Load / Upload**:
   - Click **"Pack 1"** in the top bar to instantly load the full 12-message dataset.
   - Or click **"Pack 2"** to test an alternate evening scenario.
   - Or click **"Upload .txt"** to upload your own custom message file.

2. **Inspect the 5 Planning Areas**:
   - Navigate to **"Event Planning"** to review Venue, 4-Hour Schedule, Food & Catering, Judging Allocation, and Budget Breakdown.

3. **Submit Dynamic Updates**:
   - Go to **"Messages"** tab. On the right panel, select any pre-built test preset (such as *"Catering Price Increase"*, *"Under-Catering Attempt"*, or *"Inadequate Venue Proposal"*) and click **"Process Message & Update Plan"**.
   - Observe how the system calls only the affected agents ($\le 5$ model calls) and displays either an accepted update or a detailed constraint rejection!

4. **Audit Execution Traces**:
   - Go to **"Model Traces"** tab to inspect every model call with sequential call numbers, model names, area tags, input tokens, and output tokens. Click **"View"** on any trace to inspect the exact prompt sent and the model output.

5. **Download Final Artifacts**:
   - Click **"Export Plan"** to download the Markdown event plan.
   - Click **"Export Trace"** to download the complete JSON audit log.

---

## 🛡️ License
MIT License. Created for the Mind to Machine AI Hackathon.
