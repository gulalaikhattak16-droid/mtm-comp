// src/services/MessageParser.js

/**
 * Parses raw text containing one or more messages in various formats:
 * - [MESSAGE-01] or [MSG-1] or Message 1:
 * - Sender: ... Date: ... Subject: ... Body
 * - Email-style or WhatsApp-style blocks
 */
export function parseRawMessages(rawText) {
  if (!rawText || !rawText.trim()) return [];

  const text = rawText.replace(/\r\n/g, '\n').trim();
  const messages = [];

  // Split strategy 1: Look for explicit message headers like [MESSAGE-01], [MSG-1], or --- Message X ---
  const headerRegex = /(?:^|\n)(?:\[(?:MESSAGE|MSG)[ -]?(\d+)\]|Message\s+(\d+)[:\n]|---\s*(?:Message\s+(\d+))?\s*---)/gi;
  const indices = [];
  let match;

  while ((match = headerRegex.exec(text)) !== null) {
    indices.push({
      index: match.index,
      length: match[0].length,
      numStr: match[1] || match[2] || match[3]
    });
  }

  if (indices.length > 0) {
    for (let i = 0; i < indices.length; i++) {
      const current = indices[i];
      const start = current.index;
      const end = (i + 1 < indices.length) ? indices[i + 1].index : text.length;
      const block = text.slice(start, end).trim();
      const parsed = parseSingleMessageBlock(block, i + 1, current.numStr);
      messages.push(parsed);
    }
    return messages;
  }

  // Split strategy 2: Double linebreaks with Sender/From patterns
  const doubleBreakBlocks = text.split(/\n\s*\n{2,}/);
  if (doubleBreakBlocks.length > 1) {
    doubleBreakBlocks.forEach((b, idx) => {
      const trimmed = b.trim();
      if (trimmed) {
        messages.push(parseSingleMessageBlock(trimmed, idx + 1));
      }
    });
    return messages;
  }

  // Single block fallback
  messages.push(parseSingleMessageBlock(text, 1));
  return messages;
}

export function parseSingleMessageBlock(block, fallbackIndex = 1, explicitNum = null) {
  const lines = block.split('\n').map(l => l.trim()).filter(Boolean);
  
  let sender = 'Unknown Sender';
  let date = 'Unknown Date';
  let subject = '';
  let bodyLines = [];
  let messageNum = explicitNum ? parseInt(explicitNum, 10) : fallbackIndex;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Check message tag like [MESSAGE-01]
    const tagMatch = line.match(/^\[?(?:MESSAGE|MSG)[ -]?(\d+)\]?/i);
    if (tagMatch) {
      messageNum = parseInt(tagMatch[1], 10);
      continue;
    }

    // Sender / From
    const senderMatch = line.match(/^(?:Sender|From)\s*:\s*(.+)$/i);
    if (senderMatch) {
      sender = senderMatch[1].trim();
      continue;
    }

    // Date / Time / Sent
    const dateMatch = line.match(/^(?:Date|Sent|Time|Timestamp)\s*:\s*(.+)$/i);
    if (dateMatch) {
      date = dateMatch[1].trim();
      continue;
    }

    // Subject
    const subjectMatch = line.match(/^Subject\s*:\s*(.+)$/i);
    if (subjectMatch) {
      subject = subjectMatch[1].trim();
      continue;
    }

    // WhatsApp style timestamp: "11/10/26, 09:30 - Ahmed Khan: text"
    const waMatch = line.match(/^\[?(\d{1,2}[/-]\d{1,2}[/-]\d{2,4},?\s+\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AP]M)?)\]?\s*(?:-\s*)?([^:]+):\s*(.+)$/i);
    if (waMatch) {
      date = waMatch[1].trim();
      sender = waMatch[2].trim();
      bodyLines.push(waMatch[3].trim());
      continue;
    }

    bodyLines.push(line);
  }

  const rawContent = bodyLines.join('\n').trim() || block;

  // Language detection (English vs Roman Urdu)
  const isRomanUrdu = detectRomanUrdu(rawContent);

  return {
    id: `msg-${String(messageNum).padStart(2, '0')}`,
    messageNumber: messageNum,
    sender,
    date,
    subject,
    rawText: block,
    content: rawContent,
    language: isRomanUrdu ? 'Roman Urdu / Mixed' : 'English',
    isRomanUrdu,
    status: 'pending', // pending, processed, conflicted, rejected, superseded
    extractedInfo: null,
    validationReason: ''
  };
}

/**
 * Detects Roman Urdu keywords
 */
export function detectRomanUrdu(text) {
  if (!text) return false;
  const urduPatterns = [
    /\b(?:kya|hai|hain|nahi|nhi|mein|mai|se|ka|ki|ke|ko|par|pe|kuch|aur|hum|aap|tum|yeh|woh|pesay|paisa|khana|biryani|banday|log|afrad|namaz|zohar|asr|lazmi|bhai|sirf|karna|hoga|hogi|kar|rakhna|kharab|theek|chahiye|bohat|mehnga|sasta|bachanay|wahan|idhar|baith|saktay|shukriya|assalam|salaam)\b/i
  ];
  return urduPatterns.some(p => p.test(text));
}
