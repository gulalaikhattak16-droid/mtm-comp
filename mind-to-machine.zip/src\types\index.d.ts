// src/types/index.d.ts
// Domain Types and Interfaces for Mind to Machine Hackathon Planning Agent

export type AreaTag = 'reading' | 'venue' | 'schedule' | 'food' | 'judging' | 'budget';

export type PlanValidityStatus = 'NOT_GENERATED' | 'FULLY_VALID' | 'VALID_WITH_WARNINGS' | 'INVALID';

export interface EventMetadata {
  eventName: string;
  location: string;
  targetParticipants: number;
  targetTeams: number;
  targetDurationHours: number;
  organizersCount: number;
  totalHeadcount: number;
}

export interface RawMessage {
  id: string;
  messageNumber: number;
  sender: string;
  date: string;
  subject?: string;
  rawText: string;
  content: string;
  language: string;
  isRomanUrdu: boolean;
  status: 'pending' | 'processed' | 'conflicted' | 'rejected' | 'superseded';
  extractedInfo?: ExtractedFact[] | null;
  validationReason?: string;
}

export interface ExtractedFact {
  sourceMessageId: string;
  category: 'metadata' | 'venue' | 'schedule' | 'food' | 'judging' | 'budget' | 'rejection_notice' | 'other';
  entity: string;
  details: Record<string, any>;
  rawQuote: string;
  isOutdated?: boolean;
  supersededBy?: string | null;
  confidence?: number;
}

export interface VenueOption {
  id: string;
  name: string;
  capacity: number;
  rentalCost: number;
  hasGenerator: boolean;
  generatorNotes: string;
  isEligible: boolean;
  eligibilityStatus: string;
  sourceMessageId: string;
}

export interface VenuePlan {
  status: 'CONFIRMED' | 'UNRESOLVED' | 'pending';
  recommended: string | null;
  seatingCapacity: number;
  rentalPrice: number;
  generatorAvailable: boolean;
  options: VenueOption[];
  reason: string;
  sourceMessageId?: string | null;
}

export interface ScheduleMilestone {
  phase: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  type: 'opening' | 'coding' | 'prayer' | 'code_freeze' | 'testing' | 'judging' | 'closing';
  description: string;
}

export interface SchedulePlan {
  status: 'CONFIRMED' | 'pending';
  startTime: string;
  endTime: string;
  durationHours: number;
  totalDurationMinutes: number;
  isExactlyFourHours: boolean;
  prayerBreakTime: string;
  codeFreezeTime: string;
  judgingWindow: string;
  timeline: ScheduleMilestone[];
  constraintsRespected: boolean;
  notes: string;
}

export interface CateringOption {
  vendor: string;
  pricePerPerson: number;
  deliveryFee: number;
  sourceMessageId: string;
}

export interface FoodPlan {
  status: 'CONFIRMED' | 'pending';
  headcountToFeed: number;
  orderQuantity: number;
  enforceMinimumMet: boolean;
  selectedMeal: string;
  pricePerPerson: number;
  deliveryCharges: number;
  totalFoodCost: number;
  availableOptions: CateringOption[];
  sourceMessageId?: string;
  notes: string;
}

export interface JudgeAssignment {
  judgeNumber: number;
  judgeName: string;
  assignedTeamRange: string;
  assignedTeamCount: number;
  estimatedTimeMinutes: number;
}

export interface JudgingPlan {
  status: 'CONFIRMED' | 'CAPACITY_WARNING' | 'pending';
  totalTeams: number;
  timeRequiredPerTeam: number;
  maxTeamsPerJudge: number;
  availableJudgingTime: number;
  requiredJudges: number;
  availableJudges: number;
  isCapacitySufficient: boolean;
  judgeList: string[];
  honorariumPerJudge: number;
  totalHonorarium: number;
  allocation: JudgeAssignment[];
  explanation: string;
}

export interface BudgetItem {
  item: string;
  cost: number;
  category: string;
  notes: string;
}

export interface BudgetPlan {
  status: 'APPROVED' | 'REJECTED_OVER_BUDGET' | 'pending';
  isValid: boolean;
  totalApprovedBudget: number;
  totalExpenditure: number;
  remainingBudget: number;
  utilizationPercentage: number;
  isWithinBudget: boolean;
  breakdown: {
    venue: number;
    food: number;
    judgesHonorarium: number;
    prizes: number;
    internet: number;
    printing: number;
    other: number;
  };
  lineItems: BudgetItem[];
  notes: string;
}

export interface ModelCallTrace {
  callNumber: number;
  timestamp: string;
  model: string;
  areaTag: AreaTag;
  input: string;
  output: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  isLiveApi: boolean;
  note?: string;
}

export interface ConflictRecord {
  id: string;
  timestamp: string;
  messageId: string;
  type: string;
  description: string;
  attemptedChange: string;
  resolution: string;
  rejected: boolean;
  reason: string;
}
