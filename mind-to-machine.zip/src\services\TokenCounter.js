// src/services/TokenCounter.js
// Deterministic token counter based on byte-pair / subword tokenization rules
// used by modern LLMs (Gemini / GPT)

export function estimateTokenCount(text) {
  if (!text || typeof text !== 'string') return 0;
  
  // Standard approximation: words, punctuation, numbers, whitespace
  // Regex matches alphanumeric words, contractions, numbers, punctuation, and whitespace
  const tokens = text.match(/[\w]+|[^\s\w]|\s+/g);
  if (!tokens) return 0;

  let count = 0;
  for (const token of tokens) {
    if (/^\s+$/.test(token)) {
      // Whitespace
      count += Math.ceil(token.length / 4);
    } else if (/^[a-zA-Z0-9]+$/.test(token)) {
      // Regular word or number
      if (token.length <= 4) {
        count += 1;
      } else {
        count += Math.ceil(token.length / 3.5);
      }
    } else {
      // Punctuation / symbols / non-ASCII (Urdu / Unicode characters take ~1-2 tokens)
      count += Math.ceil(token.length / 2);
    }
  }

  return Math.max(1, count);
}
