// src/agents/VenueAgent.js

export class VenueAgent {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;
  }

  async evaluate(facts, targetHeadcount) {
    const venueFacts = facts.filter(f => f.category === 'venue');
    const promptText = `Evaluate the following venue options for Mind to Machine Hackathon in Islamabad.
Total headcount that must be accommodated: ${targetHeadcount} people (150 students + staff/mentors).
Constraints:
1. Seating capacity MUST be >= ${targetHeadcount}.
2. Generator backup is strictly MANDATORY due to Islamabad power load-shedding schedules.
3. Recommend the best feasible venue that optimizes cost and reliability.

Venue Candidates:
${JSON.stringify(venueFacts, null, 2)}
`;

    const systemInstruction = `You are the Venue Agent. Evaluate venues based on headcount capacity and generator backup. Return JSON with status, options list, recommended venue, and detailed reasoning.`;

    const result = await this.geminiService.generateContent({
      prompt: promptText,
      systemInstruction,
      areaTag: 'venue',
      fallbackHandler: () => this.evaluateDeterministic(venueFacts, targetHeadcount)
    });

    let venuePlan = null;
    try {
      const cleanJson = result.output.replace(/```json/g, '').replace(/```/g, '').trim();
      venuePlan = JSON.parse(cleanJson);
    } catch {
      venuePlan = this.evaluateDeterministic(venueFacts, targetHeadcount);
    }

    // Record trace
    this.stateStore.recordTrace({
      model: result.model,
      areaTag: 'venue',
      input: result.input,
      output: result.output,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      totalTokens: result.totalTokens,
      isLiveApi: result.isLiveApi,
      note: result.note
    });

    // Update stateStore plan
    this.stateStore.plan.venue = venuePlan;
    return venuePlan;
  }

  evaluateDeterministic(venueFacts, targetHeadcount) {
    const options = [];

    venueFacts.forEach(vf => {
      const d = vf.details;
      const capacity = d.capacity || 0;
      const rentalCost = d.rentalCost || 0;
      const hasGenerator = Boolean(d.hasGenerator);
      
      const meetsCapacity = capacity >= targetHeadcount;
      const meetsGenerator = hasGenerator;
      const isEligible = meetsCapacity && meetsGenerator;

      let eligibilityStatus = 'ELIGIBLE';
      const disqualifications = [];
      if (!meetsCapacity) {
        disqualifications.push(`Insufficient capacity (${capacity} < required ${targetHeadcount})`);
      }
      if (!meetsGenerator) {
        disqualifications.push(`No reliable generator backup (load-shedding risk)`);
      }
      if (disqualifications.length > 0) {
        eligibilityStatus = 'DISQUALIFIED: ' + disqualifications.join('; ');
      }

      options.push({
        id: vf.sourceMessageId,
        name: d.name || 'Venue Candidate',
        capacity,
        rentalCost,
        hasGenerator,
        generatorNotes: d.generatorNotes || (hasGenerator ? 'Active backup' : 'Unavailable'),
        isEligible,
        eligibilityStatus,
        sourceMessageId: vf.sourceMessageId
      });
    });

    // Pick recommended venue: lowest cost among eligible venues
    const eligibleOptions = options.filter(o => o.isEligible).sort((a, b) => a.rentalCost - b.rentalCost);
    
    if (eligibleOptions.length > 0) {
      const best = eligibleOptions[0];
      return {
        status: 'CONFIRMED',
        recommended: best.name,
        seatingCapacity: best.capacity,
        rentalPrice: best.rentalCost,
        generatorAvailable: best.hasGenerator,
        options,
        reason: `Selected "${best.name}" because it fully accommodates the required ${targetHeadcount} headcount (capacity: ${best.capacity} seats), guarantees full generator backup against Islamabad outages, and offers the best value at ${best.rentalCost.toLocaleString()} PKR.`,
        sourceMessageId: best.sourceMessageId
      };
    }

    // If none eligible, report failure
    return {
      status: 'UNRESOLVED',
      recommended: null,
      seatingCapacity: 0,
      rentalPrice: 0,
      generatorAvailable: false,
      options,
      reason: `No venue satisfies both constraints: seating capacity >= ${targetHeadcount} AND guaranteed generator backup.`,
      sourceMessageId: null
    };
  }
}
