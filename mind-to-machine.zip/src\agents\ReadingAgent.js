// src/agents/ReadingAgent.js

export class ReadingAgent {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;
  }

  async processMessages(messages) {
    if (!messages || messages.length === 0) return { facts: [] };

    const promptText = this.buildPrompt(messages);
    const systemInstruction = `You are the Reading & Extraction Agent for the "Mind to Machine Hackathon" planning system in Islamabad.
Analyze all provided messages (which may be in English, Roman Urdu, or a mix of both).
Extract all verifiable facts, numerical values (PKR, headcounts, times), venue options, catering packages, schedule milestones, judging slots, and budget items.
Preserve the exact message ID (e.g. msg-01) as the source reference for every extracted fact.
Identify any outdated information (e.g. an earlier quote superseded by a later message), contradictions, or unauthorized requests.
Respond in valid JSON format.`;

    const result = await this.geminiService.generateContent({
      prompt: promptText,
      systemInstruction,
      areaTag: 'reading',
      fallbackHandler: (p) => this.extractFactsDeterministic(messages)
    });

    let extractedFacts = [];
    try {
      // Clean JSON if returned with markdown code blocks
      const cleanJson = result.output.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      extractedFacts = parsed.facts || parsed;
    } catch {
      // If LLM returned text or failed to parse, use deterministic extractor
      extractedFacts = this.extractFactsDeterministic(messages).facts;
    }

    // Record trace in stateStore
    this.stateStore.recordTrace({
      model: result.model,
      areaTag: 'reading',
      input: result.input,
      output: result.output,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      totalTokens: result.totalTokens,
      isLiveApi: result.isLiveApi,
      note: result.note
    });

    // Attach extracted facts to messages in store
    this.attachFactsToMessages(messages, extractedFacts);

    return { facts: extractedFacts };
  }

  buildPrompt(messages) {
    let p = `Please parse the following ${messages.length} messages for the Mind to Machine Hackathon.\n`;
    messages.forEach(m => {
      p += `\n--- MESSAGE ID: ${m.id} (Number: ${m.messageNumber}) ---\n`;
      p += `Sender: ${m.sender}\nDate: ${m.date}\nLanguage: ${m.language}\nContent:\n${m.content}\n`;
    });
    p += `\nOutput a JSON object with:
{
  "facts": [
    {
      "sourceMessageId": "msg-01",
      "category": "metadata|venue|schedule|food|judging|budget|other",
      "entity": "name or key attribute",
      "details": {},
      "rawQuote": "exact quote from message",
      "isOutdated": false,
      "supersededBy": null,
      "isRejectedCandidate": false,
      "confidence": 0.95
    }
  ]
}`;
    return p;
  }

  attachFactsToMessages(messages, facts) {
    messages.forEach(m => {
      const msgFacts = facts.filter(f => f.sourceMessageId === m.id);
      m.extractedInfo = msgFacts.length > 0 ? msgFacts : [{ category: 'info', note: 'Contextual or conversational note' }];
      m.status = 'processed';
    });
  }

  /**
   * Comprehensive deterministic entity extraction for English & Roman Urdu
   */
  extractFactsDeterministic(messages) {
    const facts = [];

    messages.forEach(m => {
      const text = `${m.subject || ''} ${m.content}`;
      const msgId = m.id;

      // 1. Event Metadata (Participants, Teams, Duration, Location)
      const partMatch = text.match(/(\d+)\s*(?:registered\s+)?(?:students|participants|log|banday|afrad)/i);
      const teamMatch = text.match(/(\d+)\s*teams/i);
      const staffMatch = text.match(/(\d+)\s*(?:organizing|organizers|volunteers|mentors|committee|staff)/i);
      
      // Strict match for overall approved event budget ceiling
      const budgetMatch = text.match(/(?:approved a (?:strict )?(?:hard )?budget ceiling of|total approved budget(?: is|:)?|approved budget limit|total budget(?: of)?|budget total)[^\d]{1,25}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i) ||
                          text.match(/([\d,]+)\s*(?:PKR|Rs\.?)\s*(?:total approved budget|approve hua hai)/i);

      if (partMatch || teamMatch || budgetMatch) {
        facts.push({
          sourceMessageId: msgId,
          category: 'metadata',
          entity: 'event_params',
          details: {
            participants: partMatch ? parseInt(partMatch[1], 10) : null,
            teams: teamMatch ? parseInt(teamMatch[1], 10) : null,
            organizers: staffMatch ? parseInt(staffMatch[1], 10) : null,
            budgetLimit: budgetMatch ? parseInt(budgetMatch[1].replace(/,/g, ''), 10) : null
          },
          rawQuote: text.slice(0, 120),
          isOutdated: false
        });
      }

      // 2. Venue Options
      // Looks for Venue, Hall, Auditorium, Hub, Center, Capacity, Generator
      const isVenueRelated = /venue|hall|auditorium|tech hub|center|seating|capacity|generator/i.test(text);
      if (isVenueRelated) {
        let venueName = 'Proposed Venue';
        const optMatch = text.match(/(?:Venue\s+Option\s+\d+\s*-\s*|Option\s+\d+\s*-\s*)([A-Za-z0-9 -]+?(?:Hub|Hall\s+[A-Z0-9]+|Auditorium|Center|Hall|Campus))/i);
        const nameMatch = text.match(/([A-Z][a-zA-Z0-9 -]+?(?:Tech Hub|Convention Hall [A-Z0-9]+|Campus Auditorium|Community Center|Community Hall|Friendship Center Hall \d+))/i);
        
        if (optMatch) {
          venueName = optMatch[1].trim();
        } else if (nameMatch) {
          venueName = nameMatch[1].trim();
        } else {
          const directMatch = text.match(/venue[:\s]+([A-Za-z0-9 -]+)/i);
          if (directMatch) venueName = directMatch[1].trim();
        }

        // Clean any leading prefixes like "Venue Quote - " or "Venue - "
        venueName = venueName.replace(/^(?:Venue\s*(?:Quote|Option\s*\d*|Proposal)?\s*[-:]\s*)/i, '').trim();

        const capMatch = text.match(/(?:capacity|seating|seats|baith saktay|accommodate)[^\d]{1,20}(\d+)/i) ||
                         text.match(/(\d+)\s*(?:persons?|seats?|people|capacity)/i);
        const rentMatch = text.match(/(?:rent|cost|rental|price)[^\d]{1,20}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i) ||
                          text.match(/([\d,]+)\s*(?:PKR|Rs\.?)\s*(?:rent|cost)/i);
        const hasGen = /(?:heavy generator|full generator|generator backup|dual industrial generator|backup available)/i.test(text) &&
                       !/(?:generator kharab|no generator|generator nahi)/i.test(text);
        const genBroken = /(?:generator kharab|no generator|generator nahi|will not provide fuel)/i.test(text);

        if (capMatch || rentMatch) {
          facts.push({
            sourceMessageId: msgId,
            category: 'venue',
            entity: venueName,
            details: {
              name: venueName,
              capacity: capMatch ? parseInt(capMatch[1], 10) : 0,
              rentalCost: rentMatch ? parseInt(rentMatch[1].replace(/,/g, ''), 10) : 0,
              hasGenerator: hasGen && !genBroken,
              generatorNotes: genBroken ? 'Generator broken/unavailable' : (hasGen ? 'Full generator backup' : 'Unspecified')
            },
            rawQuote: text.slice(0, 160),
            isOutdated: false
          });
        }
      }

      // 3. Catering / Food
      const isFoodRelated = /biryani|pulao|catering|lunch|food|meal|boxes|khana|rate|person|delivery/i.test(text);
      if (isFoodRelated) {
        // Check for under-order suggestion first
        const underOrderMatch = text.match(/(?:sirf|only|order|manage)\s*(\d+)\s*(?:boxes|box)/i);
        const isReductionSuggestion = /(?:pesay bachanay|save money|sab students khana nahi khatay|sirf \d+ boxes)/i.test(text);
        if (isReductionSuggestion && underOrderMatch) {
          facts.push({
            sourceMessageId: msgId,
            category: 'food',
            entity: 'Under-Catering Suggestion',
            details: {
              vendor: 'Student Suggestion',
              isUnderOrderProposal: true,
              suggestedQuantity: parseInt(underOrderMatch[1], 10)
            },
            rawQuote: text.slice(0, 160),
            isOutdated: false
          });
        }

        // Detect specific vendors mentioned in the message
        const knownVendors = ['Royal Biryani', 'Savour Foods', 'Biryani Master', 'Cheezious'];
        const foundVendors = knownVendors.filter(v => new RegExp(v, 'i').test(text));

        if (foundVendors.length > 0) {
          foundVendors.forEach(vendor => {
            // Find price near this vendor or in text
            // e.g. "Royal Biryani ... 410 PKR" or "Savour Foods ... 420 PKR"
            const vendorRegex = new RegExp(`${vendor}[^\\d]{1,60}([\\d,]+)\\s*(?:PKR|Rs\\.?|per)`, 'i');
            const nearMatch = text.match(vendorRegex);
            const genericPrice = text.match(/([\d,]+)\s*(?:PKR|Rs\.?)\s*(?:per (?:person|box|head)|each)/i);
            const price = nearMatch ? parseInt(nearMatch[1].replace(/,/g, ''), 10) : (genericPrice ? parseInt(genericPrice[1].replace(/,/g, ''), 10) : null);

            // Find delivery near vendor
            const delNear = text.match(new RegExp(`${vendor}[^\\d]{1,120}(?:delivery|fee)[^\\d]{1,20}([\\d,]+)`, 'i')) ||
                            text.match(/(?:delivery|delivery charge)[^\d]{1,20}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);
            const deliveryFee = delNear ? parseInt(delNear[1].replace(/,/g, ''), 10) : 0;

            if (price) {
              facts.push({
                sourceMessageId: msgId,
                category: 'food',
                entity: vendor,
                details: {
                  vendor,
                  pricePerPerson: price,
                  deliveryFee,
                  isUnderOrderProposal: false
                },
                rawQuote: text.slice(0, 160),
                isOutdated: false
              });
            }
          });
        } else {
          // Generic vendor
          const genericPrice = text.match(/([\d,]+)\s*(?:PKR|Rs\.?)\s*(?:per (?:person|box|head)|each)/i);
          const delMatch = text.match(/(?:delivery|delivery charge)[^\d]{1,20}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);
          if (genericPrice) {
            facts.push({
              sourceMessageId: msgId,
              category: 'food',
              entity: 'Catering Vendor',
              details: {
                vendor: 'Catering Vendor',
                pricePerPerson: parseInt(genericPrice[1].replace(/,/g, ''), 10),
                deliveryFee: delMatch ? parseInt(delMatch[1].replace(/,/g, ''), 10) : 0,
                isUnderOrderProposal: false
              },
              rawQuote: text.slice(0, 160),
              isOutdated: false
            });
          }
        }
      }

      // 4. Schedule & Timeline
      const isScheduleRelated = /schedule|timeline|hours|opening|prayer|zohar|zuhr|asr|namaz|break|freeze|testing|submission|demo/i.test(text);
      if (isScheduleRelated) {
        const prayerMatch = text.match(/(?:zuhr|zohar|asr|prayer|namaz)[^\d]{1,30}(\d{1,2}:\d{2})\s*(?:to|-)\s*(\d{1,2}:\d{2})/i) ||
                            text.match(/(\d+)\s*minute[s]?\s*(?:prayer|namaz|break)/i);
        const freezeMatch = text.match(/(?:code freeze|freeze)[^\d]{1,30}(\d{1,2}:\d{2})/i) ||
                            text.match(/(?:code freeze|freeze)[^\d]{1,30}(\d+)\s*minutes? before/i);
        const timeSpanMatch = text.match(/(\d{1,2}:\d{2})\s*(?:to|-)\s*(\d{1,2}:\d{2})/i);

        facts.push({
          sourceMessageId: msgId,
          category: 'schedule',
          entity: 'schedule_spec',
          details: {
            timeSpan: timeSpanMatch ? `${timeSpanMatch[1]} - ${timeSpanMatch[2]}` : null,
            prayerBreak: prayerMatch ? prayerMatch[0] : null,
            codeFreeze: freezeMatch ? freezeMatch[0] : null,
            rawTimelineText: text
          },
          rawQuote: text.slice(0, 160),
          isOutdated: false
        });
      }

      // 5. Judging & Evaluation
      const isJudgingRelated = /judge|judging|judges|teams per judge|honorarium|evaluat/i.test(text);
      if (isJudgingRelated) {
        const judgeCountMatch = text.match(/(\d+)\s*(?:industry expert )?judges/i) ||
                                text.match(/confirmed\s*(\d+)\s*judges/i);
        const honorariumMatch = text.match(/([\d,]+)\s*(?:PKR|Rs\.?)\s*(?:per judge|each judge|honorarium)/i) ||
                                text.match(/honorarium[^\d]{1,20}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);
        const timePerTeam = text.match(/(\d+)\s*minutes?\s*(?:for demo|per team)/i);
        const maxTeamsPerJudge = text.match(/at most\s*(\d+)\s*teams/i) || text.match(/assess\s*(\d+)\s*teams/i);
        const windowMatch = text.match(/(\d+)-minute judging/i) || text.match(/(\d+)\s*minutes?\s*(?:judging session|judging window|demo block)/i);

        // Extract judge names if enumerated
        const judgeNames = [];
        const judgeLineMatches = text.match(/\d\.\s*([A-Za-z. ]+)/g);
        if (judgeLineMatches) {
          judgeLineMatches.forEach(j => judgeNames.push(j.replace(/^\d\.\s*/, '').trim()));
        }

        facts.push({
          sourceMessageId: msgId,
          category: 'judging',
          entity: 'judging_spec',
          details: {
            confirmedCount: judgeCountMatch ? parseInt(judgeCountMatch[1], 10) : (judgeNames.length || null),
            honorarium: honorariumMatch ? parseInt(honorariumMatch[1].replace(/,/g, ''), 10) : 5000,
            timePerTeam: timePerTeam ? parseInt(timePerTeam[1], 10) : 5,
            maxTeamsPerJudge: maxTeamsPerJudge ? parseInt(maxTeamsPerJudge[1], 10) : 10,
            judgingWindowMinutes: windowMatch ? parseInt(windowMatch[1], 10) : 45,
            judgeNames
          },
          rawQuote: text.slice(0, 160),
          isOutdated: false
        });
      }

      // 6. Budget Line Items & Fixed Expenses
      const prizeMatch = text.match(/(?:Total\s+Prizes?|Prizes?\s*Total)[^\d]{1,25}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i) ||
                         text.match(/(?:prizes?|cash prizes?)[^\d]{1,30}(?:PKR|Rs\.?|Rs)?\s*([\d,]{4,})/i) ||
                         text.match(/([\d,]{4,})\s*(?:PKR|Rs\.?)\s*(?:total prizes|prizes)/i);
      const internetMatch = text.match(/(?:internet|fiber|wi-fi)[^\d]{1,30}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);
      const printingMatch = text.match(/(?:badges|printing|certificates|branding)[^\d]{1,30}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);
      const otherMatch = text.match(/(?:first aid|stationary|contingency|refreshments)[^\d]{1,30}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);
      const extraActivityMatch = text.match(/(?:VR Gaming|extra activity|videography)[^\d]{1,30}(?:PKR|Rs\.?|Rs)?\s*([\d,]+)/i);

      if (prizeMatch || internetMatch || printingMatch || otherMatch || extraActivityMatch) {
        facts.push({
          sourceMessageId: msgId,
          category: 'budget',
          entity: 'budget_items',
          details: {
            prizes: prizeMatch ? parseInt(prizeMatch[1].replace(/,/g, ''), 10) : 0,
            internet: internetMatch ? parseInt(internetMatch[1].replace(/,/g, ''), 10) : 0,
            printing: printingMatch ? parseInt(printingMatch[1].replace(/,/g, ''), 10) : 0,
            other: otherMatch ? parseInt(otherMatch[1].replace(/,/g, ''), 10) : 0,
            extraActivityCost: extraActivityMatch ? parseInt(extraActivityMatch[1].replace(/,/g, ''), 10) : 0
          },
          rawQuote: text.slice(0, 160),
          isOutdated: false
        });
      }

      // 7. Rejections / Explicit Denials
      const rejectionMatch = text.match(/(?:absolutely rejected|denied|under-catering is strictly prohibited|cannot be approved|reject kar do)/i);
      if (rejectionMatch) {
        facts.push({
          sourceMessageId: msgId,
          category: 'rejection_notice',
          entity: 'management_override',
          details: {
            text: text
          },
          rawQuote: text.slice(0, 160),
          isOutdated: false
        });
      }
    });

    return { facts };
  }
}
