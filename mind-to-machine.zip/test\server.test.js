// test/server.test.js
import assert from 'node:assert';
import test from 'node:test';
import { EventEmitter } from 'events';

// In-process mock request/response helper that avoids TCP socket restrictions
function invokeServer(server, method, urlPath, body = null, headers = {}) {
  return new Promise((resolve) => {
    const req = new EventEmitter();
    req.method = method;
    req.url = urlPath;
    req.headers = { host: 'localhost', ...headers };

    const res = new EventEmitter();
    let resBody = '';
    let statusCode = 200;
    let headersSent = {};

    res.writeHead = (status, h = {}) => {
      statusCode = status;
      headersSent = { ...headersSent, ...h };
    };

    res.setHeader = (k, v) => {
      headersSent[k] = v;
    };

    res.write = (chunk) => {
      resBody += chunk;
    };

    res.end = (chunk) => {
      if (chunk) resBody += chunk;
      resolve({
        status: statusCode,
        headers: headersSent,
        body: resBody
      });
    };

    server.emit('request', req, res);

    if (body) {
      req.emit('data', Buffer.from(typeof body === 'string' ? body : JSON.stringify(body)));
    }
    req.emit('end');
  });
}

test('Server API routes: status, batch processing, export plan and export trace', async () => {
  process.env.NODE_ENV = 'test';
  const { server } = await import('../src/server.js');

  // 1. GET /api/status
  const statusRes = await invokeServer(server, 'GET', '/api/status');
  assert.strictEqual(statusRes.status, 200);
  const statusData = JSON.parse(statusRes.body);
  assert.strictEqual(statusData.status, 'online');

  // 2. POST /api/process-batch with Pack 1
  const batchRes = await invokeServer(server, 'POST', '/api/process-batch', { samplePack: 1 });
  assert.strictEqual(batchRes.status, 200);
  const batchData = JSON.parse(batchRes.body);
  assert.strictEqual(batchData.success, true);
  assert.strictEqual(batchData.messageCount, 12);
  assert.strictEqual(batchData.summary.plan.venue.recommended, 'Islamabad Convention Hall B');
  assert.strictEqual(batchData.summary.overallValidity.isValid, true);

  // 3. GET /api/export/plan
  const exportPlanRes = await invokeServer(server, 'GET', '/api/export/plan');
  assert.strictEqual(exportPlanRes.status, 200);
  assert.ok(exportPlanRes.body.includes('Mind to Machine Hackathon - Operational Event Plan'));

  // 4. GET /api/export/trace
  const exportTraceRes = await invokeServer(server, 'GET', '/api/export/trace');
  assert.strictEqual(exportTraceRes.status, 200);
  const traceData = JSON.parse(exportTraceRes.body);
  assert.ok(traceData.executionTraces.length >= 5);
});
