// test/planner.test.js
import assert from 'node:assert';
import test from 'node:test';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { parseRawMessages } from '../src/services/MessageParser.js';
import { StateStore } from '../src/services/StateStore.js';
import { GeminiService } from '../src/services/GeminiService.js';
import { AgentOrchestrator } from '../src/agents/AgentOrchestrator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SAMPLE_PACK_1 = path.join(__dirname, '..', 'sample_data', 'hackathon_messages_pack1.txt');

test('MessageParser correctly parses sample pack 1', () => {
  const text = fs.readFileSync(SAMPLE_PACK_1, 'utf-8');
  const messages = parseRawMessages(text);

  assert.strictEqual(messages.length, 12, 'Should parse exactly 12 messages');
  assert.strictEqual(messages[0].id, 'msg-01');
  assert.strictEqual(messages[0].sender, 'Event Director (Ahmed Khan)');
  
  // Test Roman Urdu detection
  const urduMsg = messages.find(m => m.id === 'msg-02');
  assert.ok(urduMsg, 'Should find msg-02');
  assert.strictEqual(urduMsg.isRomanUrdu, true, 'msg-02 should be detected as Roman Urdu');
});

test('AgentOrchestrator generates complete valid plan for Pack 1', async () => {
  const text = fs.readFileSync(SAMPLE_PACK_1, 'utf-8');
  const messages = parseRawMessages(text);

  const gemini = new GeminiService('', 'gemini-2.0-flash');
  const store = new StateStore();
  const orchestrator = new AgentOrchestrator(gemini, store);

  const summary = await orchestrator.processAllMessages(messages);

  // Check venue
  assert.ok(summary.plan.venue.recommended, 'A venue must be recommended');
  assert.strictEqual(summary.plan.venue.recommended, 'Islamabad Convention Hall B', 'Should recommend Convention Hall B (capacity 220, generator available)');
  assert.strictEqual(summary.plan.venue.generatorAvailable, true, 'Recommended venue must have generator');

  // Check food headcount
  assert.ok(summary.plan.food.orderQuantity >= 162, 'Food order quantity must be >= total headcount (150 students + staff)');
  assert.strictEqual(summary.plan.food.selectedMeal, 'Royal Biryani', 'Should pick latest updated quote from Royal Biryani (410 PKR)');
  assert.strictEqual(summary.plan.food.pricePerPerson, 410, 'Should use updated price of 410 PKR');

  // Check schedule
  assert.strictEqual(summary.plan.schedule.durationHours, 4, 'Schedule duration must be 4 hours');
  assert.ok(summary.plan.schedule.timeline.length >= 6, 'Schedule must include key phases');

  // Check judging
  assert.strictEqual(summary.plan.judging.totalTeams, 50, 'Must judge 50 teams');
  assert.strictEqual(summary.plan.judging.availableJudges, 5, 'Should have 5 confirmed judges');
  assert.strictEqual(summary.plan.judging.isCapacitySufficient, true, '5 judges should be sufficient');

  // Check budget
  assert.ok(summary.plan.budget.totalExpenditure <= summary.plan.budget.totalApprovedBudget, 'Must be within budget');
  assert.strictEqual(summary.overallValidity.isValid, true, 'Overall plan must be valid');

  // Check token traces
  assert.ok(summary.modelTraces.length >= 5, 'Must have at least 5 model traces for the 5 agents');
  assert.ok(summary.tokenUsage.totalTokens > 0, 'Total tokens must be counted');
});

test('Conflict detection rejects under-catering and inadequate venue', async () => {
  const text = fs.readFileSync(SAMPLE_PACK_1, 'utf-8');
  const messages = parseRawMessages(text);

  const gemini = new GeminiService('', 'gemini-2.0-flash');
  const store = new StateStore();
  const orchestrator = new AgentOrchestrator(gemini, store);
  await orchestrator.processAllMessages(messages);

  // Test dynamic under-catering attempt
  const underCaterMsg = {
    id: 'msg-dynamic-01',
    messageNumber: 13,
    sender: 'Budget Cutter (Hamza)',
    date: '2026-11-13 10:00 PKT',
    content: 'Sirf 100 boxes order karein pesay bachanay k liye.',
    language: 'Roman Urdu',
    isRomanUrdu: true
  };

  const res1 = await orchestrator.processNewMessage(underCaterMsg);
  assert.strictEqual(res1.accepted, false, 'Under-catering must be rejected');
  assert.ok(res1.message.includes('REJECTED'), 'Rejection reason must be stated');

  // Verify plan remained valid
  assert.ok(store.plan.food.orderQuantity >= 162, 'Original food order quantity must be preserved');
});

test('AgentOrchestrator generates valid plan for Pack 2 (Evening slot, 400k budget, 6 judges)', async () => {
  const pack2Path = path.join(__dirname, '..', 'sample_data', 'hackathon_messages_pack2.txt');
  const text = fs.readFileSync(pack2Path, 'utf-8');
  const messages = parseRawMessages(text);

  const gemini = new GeminiService('', 'gemini-2.0-flash');
  const store = new StateStore();
  const orchestrator = new AgentOrchestrator(gemini, store);

  const summary = await orchestrator.processAllMessages(messages);

  assert.strictEqual(summary.metadata.targetParticipants, 150);
  assert.strictEqual(summary.plan.venue.recommended, 'Pak-China Friendship Center Hall 3');
  assert.strictEqual(summary.plan.venue.rentalPrice, 80000);
  assert.strictEqual(summary.plan.schedule.startTime, '14:00');
  assert.strictEqual(summary.plan.schedule.endTime, '18:00');
  assert.strictEqual(summary.plan.judging.availableJudges, 6);
  assert.strictEqual(summary.plan.budget.totalApprovedBudget, 400000);
  assert.ok(summary.overallValidity.isValid, 'Pack 2 plan must be valid');
});
