// src/agents/ConflictResolver.js

export class ConflictResolver {
  constructor(stateStore) {
    this.stateStore = stateStore;
  }

  /**
   * Evaluates an incoming message or proposed fact against current constraints.
   * Returns: { isAccepted: boolean, reason: string, affectedAreas: string[], proposedChange: any }
   */
  evaluateProposal(message, extractedFacts, currentPlan, metadata) {
    const affectedAreas = new Set();
    const targetHeadcount = metadata.targetParticipants + (metadata.organizersCount || 12) + (currentPlan.judging?.availableJudges || 5);
    const approvedBudget = currentPlan.budget?.totalApprovedBudget || 350000;

    let isAccepted = true;
    let reason = 'Message verified and aligned with event constraints.';
    const changes = [];

    for (const fact of extractedFacts) {
      // 1. Food / Catering under-order check
      if (fact.category === 'food' && fact.details?.isUnderOrderProposal) {
        const qty = fact.details.suggestedQuantity;
        if (qty < targetHeadcount) {
          isAccepted = false;
          reason = `REJECTED: Requested food order (${qty} boxes) is less than required headcount (${targetHeadcount} attendees). Under-catering violates event policy.`;
          this.stateStore.recordConflict({
            messageId: message.id,
            type: 'UNDER_CATERING_CONFLICT',
            description: `Attempted under-catering: ${qty} boxes for ${targetHeadcount} people`,
            attemptedChange: `Set food quantity to ${qty}`,
            resolution: `Rejected. Maintained valid order quantity of ${targetHeadcount} boxes.`,
            rejected: true,
            reason
          });
          return { isAccepted: false, reason, affectedAreas: [] };
        }
      }

      // 2. Venue capacity & generator check
      if (fact.category === 'venue') {
        affectedAreas.add('venue');
        affectedAreas.add('budget'); // venue price affects budget
        const cap = fact.details.capacity || 0;
        const hasGen = fact.details.hasGenerator;

        if (cap < targetHeadcount) {
          isAccepted = false;
          reason = `REJECTED: Proposed venue "${fact.details.name}" seating capacity (${cap}) cannot accommodate the total headcount of ${targetHeadcount} people.`;
          this.stateStore.recordConflict({
            messageId: message.id,
            type: 'VENUE_CAPACITY_CONFLICT',
            description: `Proposed venue capacity ${cap} < required ${targetHeadcount}`,
            attemptedChange: `Switch venue to ${fact.details.name}`,
            resolution: `Rejected. Existing venue plan preserved.`,
            rejected: true,
            reason
          });
          return { isAccepted: false, reason, affectedAreas: [] };
        }

        if (!hasGen) {
          isAccepted = false;
          reason = `REJECTED: Proposed venue "${fact.details.name}" lacks reliable generator backup. Islamabad power load-shedding requires mandatory backup.`;
          this.stateStore.recordConflict({
            messageId: message.id,
            type: 'VENUE_GENERATOR_CONFLICT',
            description: `Proposed venue has no generator backup`,
            attemptedChange: `Switch venue to ${fact.details.name}`,
            resolution: `Rejected. Existing venue plan preserved.`,
            rejected: true,
            reason
          });
          return { isAccepted: false, reason, affectedAreas: [] };
        }
      }

      // 3. Catering price update (valid update)
      if (fact.category === 'food' && fact.details?.pricePerPerson) {
        affectedAreas.add('food');
        affectedAreas.add('budget');
        changes.push(`Catering price updated to ${fact.details.pricePerPerson} PKR/person`);
      }

      // 4. Schedule updates (prayer, freeze, timing)
      if (fact.category === 'schedule') {
        affectedAreas.add('schedule');
        changes.push('Schedule timeline or prayer timing updated');
      }

      // 5. Judging updates (judge dropout / additions)
      if (fact.category === 'judging') {
        affectedAreas.add('judging');
        affectedAreas.add('budget');
        changes.push('Judging capacity or judge roster updated');
      }

      // 6. Unauthorized budget additions
      if (fact.category === 'budget' && fact.details?.extraActivityCost) {
        const extra = fact.details.extraActivityCost;
        const currentExp = currentPlan.budget?.totalExpenditure || 0;
        if (currentExp + extra > approvedBudget) {
          isAccepted = false;
          reason = `REJECTED: Requested extra activity of ${extra.toLocaleString()} PKR would cause total expenditure to exceed the approved ceiling of ${approvedBudget.toLocaleString()} PKR.`;
          this.stateStore.recordConflict({
            messageId: message.id,
            type: 'BUDGET_OVERRUN_CONFLICT',
            description: `Extra cost +${extra} PKR breaches budget ceiling`,
            attemptedChange: `Add extra expense +${extra} PKR`,
            resolution: `Rejected. Preserved existing budget.`,
            rejected: true,
            reason
          });
          return { isAccepted: false, reason, affectedAreas: [] };
        }
      }
    }

    return {
      isAccepted,
      reason: isAccepted ? (changes.join('; ') || reason) : reason,
      affectedAreas: Array.from(affectedAreas)
    };
  }
}
