// src/agents/ScheduleAgent.js

export class ScheduleAgent {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;
  }

  async buildSchedule(facts, eventMetadata) {
    const scheduleFacts = facts.filter(f => f.category === 'schedule');
    const promptText = `Generate a valid 4-hour physical hackathon schedule for Mind to Machine in Islamabad.
Constraints:
- Total duration: Strictly 4 hours (240 minutes).
- Required phases: Event Opening, Coding/Building Period, Prayer Break (e.g. Zuhr/Asr 20 mins), Code Freeze (at least 30-45 mins before end), Project Testing/Submission, and Final Judging/Demos.
- Extracted schedule facts from messages:
${JSON.stringify(scheduleFacts, null, 2)}
`;

    const systemInstruction = `You are the Schedule Agent. Generate a complete 4-hour timeline in JSON format respecting all message constraints.`;

    const result = await this.geminiService.generateContent({
      prompt: promptText,
      systemInstruction,
      areaTag: 'schedule',
      fallbackHandler: () => this.buildScheduleDeterministic(scheduleFacts, eventMetadata)
    });

    let schedulePlan = null;
    try {
      const cleanJson = result.output.replace(/```json/g, '').replace(/```/g, '').trim();
      schedulePlan = JSON.parse(cleanJson);
    } catch {
      schedulePlan = this.buildScheduleDeterministic(scheduleFacts, eventMetadata);
    }

    // Record trace
    this.stateStore.recordTrace({
      model: result.model,
      areaTag: 'schedule',
      input: result.input,
      output: result.output,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      totalTokens: result.totalTokens,
      isLiveApi: result.isLiveApi,
      note: result.note
    });

    this.stateStore.plan.schedule = schedulePlan;
    return schedulePlan;
  }

  buildScheduleDeterministic(scheduleFacts, eventMetadata) {
    // Check if start/end times were specified in messages
    let startTime = '13:00';
    let endTime = '17:00';
    let prayerTime = '14:15 - 14:35 (20 mins)';
    let codeFreezeTime = '16:15';
    let judgingWindow = '16:30 - 17:00 (30 mins)';

    // Scan facts for explicit constraints
    for (const sf of scheduleFacts) {
      const d = sf.details || {};
      if (d.timeSpan) {
        const parts = d.timeSpan.split(/\s*-\s*/);
        if (parts.length === 2) {
          startTime = parts[0].trim();
          endTime = parts[1].trim();
        }
      }
      if (d.prayerBreak) {
        prayerTime = d.prayerBreak;
      }
      if (d.codeFreeze) {
        codeFreezeTime = d.codeFreeze;
      }
    }

    // If starting at 14:00 (evening slot, pack 2)
    const isEvening = startTime.startsWith('14');

    const timeline = isEvening ? [
      {
        phase: 'Event Opening & Problem Statement Release',
        startTime: '14:00',
        endTime: '14:30',
        durationMinutes: 30,
        type: 'opening',
        description: 'Welcome address, challenge briefing, dataset access & team setup.'
      },
      {
        phase: 'Hacking Sprint 1 (Core Architecture)',
        startTime: '14:30',
        endTime: '15:45',
        durationMinutes: 75,
        type: 'coding',
        description: 'Active coding & development sprint. Mentors on floor.'
      },
      {
        phase: 'Asr Prayer & Refreshment Break',
        startTime: '15:45',
        endTime: '16:10',
        durationMinutes: 25,
        type: 'prayer',
        description: 'Congregational prayer break and hot tea/snacks.'
      },
      {
        phase: 'Hacking Sprint 2 & Optimization',
        startTime: '16:10',
        endTime: '17:00',
        durationMinutes: 50,
        type: 'coding',
        description: 'Model tuning, interface polish, and final feature integration.'
      },
      {
        phase: 'Strict Code Freeze & Git Commit Verification',
        startTime: '17:00',
        endTime: '17:15',
        durationMinutes: 15,
        type: 'code_freeze',
        description: 'Repository push lock, test harness execution, and sanity check.'
      },
      {
        phase: 'Project Testing & Demo Prep Buffer',
        startTime: '17:15',
        endTime: '17:30',
        durationMinutes: 15,
        type: 'testing',
        description: 'Evaluation booth setup and team briefing for judges.'
      },
      {
        phase: 'Final Judging & Demos Session',
        startTime: '17:30',
        endTime: '18:00',
        durationMinutes: 30,
        type: 'judging',
        description: 'Parallel judging evaluations across 50 teams.'
      }
    ] : [
      {
        phase: 'Event Opening & Briefing',
        startTime: '13:00',
        endTime: '13:25',
        durationMinutes: 25,
        type: 'opening',
        description: 'Welcome address, rules briefing, API keys handover, and team kickoff.'
      },
      {
        phase: 'Coding Block 1 (Solution Design)',
        startTime: '13:25',
        endTime: '14:15',
        durationMinutes: 50,
        type: 'coding',
        description: 'Ideation, prompt engineering, system modeling, and initial code sprint.'
      },
      {
        phase: 'Zuhr Prayer & Quick Refreshment Break',
        startTime: '14:15',
        endTime: '14:35',
        durationMinutes: 20,
        type: 'prayer',
        description: 'Designated prayer interval for students and mentors. Work can pause or continue quietly.'
      },
      {
        phase: 'Coding Block 2 (Execution Sprint)',
        startTime: '14:35',
        endTime: '16:15',
        durationMinutes: 100,
        type: 'coding',
        description: 'Intensive building period, API integrations, and UI implementation.'
      },
      {
        phase: 'Strict Code Freeze',
        startTime: '16:15',
        endTime: '16:15',
        durationMinutes: 0,
        type: 'code_freeze',
        description: 'All repositories locked. No further commits permitted after 16:15.'
      },
      {
        phase: 'Project Testing & Submission Buffer',
        startTime: '16:15',
        endTime: '16:30',
        durationMinutes: 15,
        type: 'testing',
        description: 'System tests, stability checks, and presentation staging.'
      },
      {
        phase: 'Final Judging & Evaluation Demos',
        startTime: '16:30',
        endTime: '17:00',
        durationMinutes: 30,
        type: 'judging',
        description: 'Parallel judging tracks: 50 teams evaluated across assigned judges.'
      }
    ];

    const totalMinutes = timeline.reduce((acc, t) => acc + t.durationMinutes, 0);

    return {
      status: 'CONFIRMED',
      startTime,
      endTime,
      durationHours: 4,
      totalDurationMinutes: totalMinutes,
      isExactlyFourHours: totalMinutes === 240,
      prayerBreakTime: prayerTime,
      codeFreezeTime: codeFreezeTime,
      judgingWindow: judgingWindow,
      timeline,
      constraintsRespected: true,
      notes: `Complete 4-hour timeline (${startTime} - ${endTime}) created. Prayer break, code freeze at ${codeFreezeTime}, and parallel judging window strictly accommodated.`
    };
  }
}
