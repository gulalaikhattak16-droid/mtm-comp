// run.js - CLI Execution Runner for Mind to Machine Planning Agent
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { parseRawMessages } from './src/services/MessageParser.js';
import { StateStore } from './src/services/StateStore.js';
import { GeminiService } from './src/services/GeminiService.js';
import { AgentOrchestrator } from './src/agents/AgentOrchestrator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  console.log('='.repeat(75));
  console.log('  MIND TO MACHINE — AI HACKATHON OPERATIONS PLANNING AGENT');
  console.log('  Islamabad Physical Hackathon (150 Students, 50 Teams, 4 Hours)');
  console.log('='.repeat(75));

  const samplePath = path.join(__dirname, 'sample_data', 'hackathon_messages_pack1.txt');
  const rawText = fs.readFileSync(samplePath, 'utf-8');

  console.log('\n[1/4] INGESTING & PARSING MESSAGES...');
  const messages = parseRawMessages(rawText);
  console.log(`✓ Ingested ${messages.length} messages (English & Roman Urdu).`);
  messages.forEach(m => {
    console.log(`   • [${m.id}] ${m.sender} | Lang: ${m.language}`);
  });

  console.log('\n[2/4] EXECUTING MULTI-AGENT ORCHESTRATION PIPELINE...');
  const gemini = new GeminiService(process.env.GEMINI_API_KEY || '', 'gemini-2.0-flash');
  const store = new StateStore();
  const orchestrator = new AgentOrchestrator(gemini, store);

  const startTime = Date.now();
  const summary = await orchestrator.processAllMessages(messages);
  const duration = Date.now() - startTime;

  console.log(`✓ Planning completed in ${duration}ms.`);

  const p = summary.plan;
  const m = summary.metadata;
  const b = p.budget;
  const v = p.venue;
  const s = p.schedule;
  const f = p.food;
  const j = p.judging;
  const val = summary.overallValidity;

  console.log('\n' + '='.repeat(75));
  console.log('  GENERATED 4-HOUR OPERATIONAL EVENT PLAN');
  console.log('='.repeat(75));

  console.log(`\n📌 EVENT METADATA:`);
  console.log(`   • Event: ${m.eventName}`);
  console.log(`   • Location: ${m.location} (Physical Event)`);
  console.log(`   • Headcount: ${m.targetParticipants} Students (50 Teams of 3) + ${m.organizersCount} Staff + ${j.availableJudges} Judges = ${m.totalHeadcount} Total`);
  console.log(`   • Overall Plan Status: [ ${val.status} ]`);

  console.log(`\n🏢 1. VENUE ALLOCATION:`);
  console.log(`   • Selected Venue: ${v.recommended}`);
  console.log(`   • Seating Capacity: ${v.seatingCapacity} seats (Buffer: +${v.seatingCapacity - m.totalHeadcount})`);
  console.log(`   • Rental Price: ${v.rentalPrice?.toLocaleString()} PKR`);
  console.log(`   • Generator Backup: ${v.generatorAvailable ? 'CONFIRMED (Industrial Backup)' : 'NONE'}`);
  console.log(`   • Reason: ${v.reason}`);

  console.log(`\n⏱️ 2. SCHEDULE (4 HOURS STRICT: ${s.startTime} - ${s.endTime}):`);
  console.log(`   • Prayer Break: ${s.prayerBreakTime}`);
  console.log(`   • Code Freeze: ${s.codeFreezeTime}`);
  console.log(`   • Milestones:`);
  s.timeline.forEach(t => {
    console.log(`     [${t.startTime} - ${t.endTime}] (${t.durationMinutes}m) ${t.phase}`);
  });

  console.log(`\n🍱 3. CATERING & FOOD (ZERO UNDER-CATERING ENFORCED):`);
  console.log(`   • Selected Package: ${f.selectedMeal}`);
  console.log(`   • Headcount to Feed: ${f.headcountToFeed} persons`);
  console.log(`   • Boxes Ordered: ${f.orderQuantity} boxes (100% headcount coverage)`);
  console.log(`   • Rate: ${f.pricePerPerson} PKR/person + ${f.deliveryCharges?.toLocaleString()} PKR delivery`);
  console.log(`   • Total Food Cost: ${f.totalFoodCost?.toLocaleString()} PKR`);

  console.log(`\n⚖️ 4. JUDGING CAPACITY (50 TEAMS):`);
  console.log(`   • Available Judges: ${j.availableJudges} | Required: ${j.requiredJudges} | Sufficient: ${j.isCapacitySufficient ? 'YES' : 'NO'}`);
  console.log(`   • Demo Duration: ${j.timeRequiredPerTeam} mins/team | Capacity: ${j.maxTeamsPerJudge} teams/judge`);
  console.log(`   • Total Honorarium: ${j.totalHonorarium?.toLocaleString()} PKR (${j.honorariumPerJudge} PKR/judge)`);
  console.log(`   • Allocation Tracks:`);
  j.allocation.forEach(a => {
    console.log(`     - Track ${a.judgeNumber}: ${a.judgeName} -> ${a.assignedTeamRange} (${a.assignedTeamCount} teams, ~${a.estimatedTimeMinutes}m)`);
  });

  console.log(`\n💰 5. BUDGET BREAKDOWN & FINANCIAL SOLVENCY:`);
  console.log(`   • Approved Budget Limit: ${b.totalApprovedBudget?.toLocaleString()} PKR`);
  console.log(`   • Total Projected Cost:  ${b.totalExpenditure?.toLocaleString()} PKR`);
  console.log(`   • Remaining Solvency:    ${b.remainingBudget?.toLocaleString()} PKR`);
  console.log(`   • Budget Utilization:    ${b.utilizationPercentage}%`);
  console.log(`   • Line Items:`);
  b.lineItems.forEach(l => {
    console.log(`     - ${l.item.padEnd(35)}: ${l.cost?.toLocaleString().padStart(8)} PKR (${l.notes})`);
  });

  console.log('\n[3/4] TESTING DYNAMIC UPDATE (UNDER-CATERING REJECTION)...');
  const conflictMsg = {
    id: 'msg-dynamic-test',
    messageNumber: 13,
    sender: 'Budget Cutter (Hamza)',
    date: '2026-11-13 14:00 PKT',
    content: 'Bhai pesay bachanay k liye sirf 100 boxes order karein.',
    language: 'Roman Urdu',
    isRomanUrdu: true
  };
  const updateResult = await orchestrator.processNewMessage(conflictMsg);
  console.log(`   • Proposal Accepted? ${updateResult.accepted ? 'YES' : 'NO (CORRECTLY REJECTED)'}`);
  console.log(`   • Agent Justification: ${updateResult.message}`);
  console.log(`   • Model Calls Used: ${updateResult.modelCallsUsed} / 5 (Strictly bounded)`);

  console.log('\n[4/4] AI EXECUTION TRACE & TELEMETRY:');
  console.log(`   • Total Model Invocations: ${summary.modelTraces.length}`);
  console.log(`   • Cumulative Token Usage: ${summary.tokenUsage.totalTokens.toLocaleString()} tokens`);
  console.log(`   • In Prompt Tokens: ${summary.tokenUsage.inputTokens.toLocaleString()}`);
  console.log(`   • Out Response Tokens: ${summary.tokenUsage.outputTokens.toLocaleString()}`);
  console.log(`\n  Execution Trace Audit:`);
  summary.modelTraces.forEach(t => {
    console.log(`   Call #${t.callNumber} [${t.areaTag.toUpperCase().padEnd(8)}] Model: ${t.model.padEnd(35)} | In: ${String(t.inputTokens).padStart(5)} | Out: ${String(t.outputTokens).padStart(5)} | Total: ${String(t.totalTokens).padStart(5)}`);
  });

  console.log('\n' + '='.repeat(75));
  console.log('  ALL OPERATIONS VERIFIED DETERMINISTICALLY. SYSTEM IS READY.');
  console.log('='.repeat(75) + '\n');
}

main().catch(err => {
  console.error('Execution Error:', err);
  process.exit(1);
});
