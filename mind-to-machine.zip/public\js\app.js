// public/js/app.js
const { useState, useEffect, useMemo, useRef } = React;
const Icons = window.Icons;

function App() {
  const [status, setStatus] = useState(null);
  const [stateSummary, setStateSummary] = useState(null);
  const [activeTab, setActiveTab] = useState('overview'); // overview, messages, planning, trace, conflicts
  const [planningSubTab, setPlanningSubTab] = useState('venue'); // venue, schedule, food, judging, budget
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [dynamicPresets, setDynamicPresets] = useState([]);
  
  // Settings Modal
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [modelSelect, setModelSelect] = useState('gemini-2.0-flash');
  const [settingsSuccess, setSettingsSuccess] = useState('');

  // Trace Inspector Modal
  const [selectedTrace, setSelectedTrace] = useState(null);

  // New Message Form
  const [newSender, setNewSender] = useState('');
  const [newContent, setNewContent] = useState('');
  const [updateFeedback, setUpdateFeedback] = useState(null);

  // Fetch initial status and dynamic presets
  useEffect(() => {
    fetchStatus();
    fetchDynamicPresets();
    fetchState();
  }, []);

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      setStatus(data);
      if (data.model) setModelSelect(data.model);
    } catch (err) {
      console.error('Status fetch error:', err);
    }
  };

  const fetchDynamicPresets = async () => {
    try {
      const res = await fetch('/api/dynamic-presets');
      const data = await res.json();
      if (data.presets) setDynamicPresets(data.presets);
    } catch (err) {
      console.error('Presets error:', err);
    }
  };

  const fetchState = async () => {
    try {
      const res = await fetch('/api/state');
      const data = await res.json();
      if (data && data.metadata) {
        setStateSummary(data);
      }
    } catch (err) {
      console.error('State error:', err);
    }
  };

  // Run full processing on sample pack or uploaded file
  const handleProcessBatch = async (packNumber = null, fileText = null) => {
    setLoading(true);
    setLoadingMsg(packNumber ? `Reading & processing Sample Pack ${packNumber}...` : 'Parsing and analyzing uploaded message file...');
    try {
      const payload = packNumber ? { samplePack: packNumber } : { text: fileText };
      const res = await fetch('/api/process-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setStateSummary(data.summary);
        fetchStatus();
      } else {
        alert(`Error: ${data.error || 'Failed to process messages'}`);
      }
    } catch (err) {
      alert(`Network error: ${err.message}`);
    } finally {
      setLoading(false);
      setLoadingMsg('');
    }
  };

  // Handle file upload
  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target.result;
      handleProcessBatch(null, content);
    };
    reader.readAsText(file);
  };

  // Submit single dynamic message
  const handleAddSingleMessage = async (e) => {
    if (e) e.preventDefault();
    if (!newContent.trim()) {
      alert('Please enter message content.');
      return;
    }
    setLoading(true);
    setLoadingMsg('Evaluating incoming message and targeted agent update (<= 5 calls)...');
    setUpdateFeedback(null);

    try {
      const res = await fetch('/api/message/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender: newSender.trim() || 'Dynamic Participant',
          content: newContent.trim(),
          date: new Date().toLocaleString()
        })
      });
      const data = await res.json();
      setUpdateFeedback({
        accepted: data.accepted,
        message: data.message,
        affectedAreas: data.affectedAreas || [],
        modelCallsUsed: data.modelCallsUsed || 1
      });
      if (data.state) {
        setStateSummary(data.state);
        fetchStatus();
      }
      setNewContent('');
      setNewSender('');
    } catch (err) {
      alert(`Error submitting message: ${err.message}`);
    } finally {
      setLoading(false);
      setLoadingMsg('');
    }
  };

  const applyPreset = (preset) => {
    setNewSender(preset.sender);
    setNewContent(preset.text);
  };

  // Save settings
  const handleSaveSettings = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: apiKeyInput,
          modelName: modelSelect
        })
      });
      const data = await res.json();
      if (data.success) {
        setSettingsSuccess('Settings updated successfully!');
        fetchStatus();
        setTimeout(() => {
          setSettingsSuccess('');
          setSettingsOpen(false);
        }, 1200);
      }
    } catch (err) {
      alert(`Failed to save settings: ${err.message}`);
    }
  };

  const handleReset = async () => {
    if (!confirm('Are you sure you want to reset all messages and plans?')) return;
    try {
      await fetch('/api/reset', { method: 'POST' });
      fetchState();
      fetchStatus();
      setUpdateFeedback(null);
    } catch (err) {
      console.error(err);
    }
  };

  const hasPlan = Boolean(stateSummary && stateSummary.plan?.venue?.recommended);
  const metadata = stateSummary?.metadata || {};
  const plan = stateSummary?.plan || {};
  const validity = stateSummary?.overallValidity || {};
  const tokenUsage = stateSummary?.tokenUsage || { inputTokens: 0, outputTokens: 0, totalTokens: 0 };
  const traces = stateSummary?.modelTraces || [];
  const messages = stateSummary?.messages || [];
  const conflicts = stateSummary?.conflicts || [];
  const rejectedMessages = stateSummary?.rejectedMessages || [];

  return (
    <div className="min-h-screen bg-[#0B0F19] text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* TOP NAVIGATION / HEADER */}
      <header className="border-b border-slate-800/80 bg-slate-900/70 backdrop-blur sticky top-0 z-40 px-4 lg:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center space-x-3.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-400 p-[1.5px] shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center text-indigo-400">
              <Icons.Brain size={22} />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                Mind to Machine
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-mono">
                  AI Ops Agent
                </span>
              </h1>
            </div>
            <p className="text-xs text-slate-400">Islamabad Physical Hackathon Autonomous Planning System</p>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center space-x-2.5">
          {/* Status Badge */}
          <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/50 text-xs">
            <span className={`w-2 h-2 rounded-full ${status?.hasGeminiKey ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span className="text-slate-300 font-mono">
              {status?.hasGeminiKey ? `Live: ${status?.model}` : 'Smart Local NLP Engine'}
            </span>
          </div>

          {/* Load Sample Buttons */}
          <div className="flex items-center bg-slate-800/80 p-0.5 rounded-lg border border-slate-700/60 text-xs font-medium">
            <button
              onClick={() => handleProcessBatch(1)}
              className="px-2.5 py-1.5 rounded-md text-slate-200 hover:bg-indigo-600/30 hover:text-indigo-300 transition"
              title="Load full 12-message dataset (English + Roman Urdu)"
            >
              Pack 1
            </button>
            <button
              onClick={() => handleProcessBatch(2)}
              className="px-2.5 py-1.5 rounded-md text-slate-200 hover:bg-purple-600/30 hover:text-purple-300 transition"
              title="Load alternate dataset (Evening slot, 400k budget)"
            >
              Pack 2
            </button>
          </div>

          {/* Upload Button */}
          <label className="cursor-pointer flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/25 transition">
            <Icons.Upload size={14} />
            <span className="hidden sm:inline">Upload .txt</span>
            <input type="file" accept=".txt" onChange={handleFileUpload} className="hidden" />
          </label>

          {/* Export Plan */}
          {hasPlan && (
            <a
              href="/api/export/plan"
              download
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition"
              title="Download Plan as Markdown file"
            >
              <Icons.Download size={14} />
              <span className="hidden sm:inline">Export Plan</span>
            </a>
          )}

          {/* Export Trace */}
          {traces.length > 0 && (
            <a
              href="/api/export/trace"
              download
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition"
              title="Download Full Execution Trace JSON"
            >
              <Icons.Activity size={14} />
              <span className="hidden sm:inline">Export Trace</span>
            </a>
          )}

          {/* Settings Button */}
          <button
            onClick={() => setSettingsOpen(true)}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition"
            title="Configure Gemini API Key & Model"
          >
            <Icons.Settings size={16} />
          </button>

          {/* Reset Button */}
          {messages.length > 0 && (
            <button
              onClick={handleReset}
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-red-500/20 border border-slate-700 text-slate-400 hover:text-red-400 transition"
              title="Reset state"
            >
              <Icons.RefreshCw size={16} />
            </button>
          )}
        </div>
      </header>

      {/* SUB-HEADER / NAV TABS */}
      <div className="border-b border-slate-800/70 bg-slate-900/40 px-4 lg:px-8 flex items-center justify-between overflow-x-auto">
        <nav className="flex space-x-1 text-sm font-medium py-2">
          {[
            { id: 'overview', label: 'Overview Dashboard', icon: Icons.Brain },
            { id: 'messages', label: `Messages (${messages.length})`, icon: Icons.MessageSquare },
            { id: 'planning', label: 'Event Planning (5 Areas)', icon: Icons.Calendar },
            { id: 'trace', label: `Model Traces (${traces.length})`, icon: Icons.Activity },
            { id: 'conflicts', label: `Conflicts & Rejections (${conflicts.length})`, icon: Icons.Shield }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition ${
                  isActive
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon size={15} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Global Plan Validity Pill */}
        {hasPlan && (
          <div className="hidden lg:flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Plan Status:</span>
            <span className={`px-2.5 py-1 rounded-full font-semibold border flex items-center gap-1.5 ${
              validity.isValid
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-red-500/10 text-red-400 border-red-500/30'
            }`}>
              {validity.isValid ? <Icons.CheckCircle2 size={13} /> : <Icons.XCircle size={13} />}
              {validity.status}
            </span>
          </div>
        )}
      </div>

      {/* LOADING OVERLAY */}
      {loading && (
        <div className="fixed inset-0 modal-overlay z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-6 max-w-md w-full text-center space-y-4 border border-indigo-500/30 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 mx-auto flex items-center justify-center text-indigo-400 animate-spin">
              <Icons.RefreshCw size={24} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">AI Agents at Work</h3>
              <p className="text-xs text-slate-400 mt-1">{loadingMsg}</p>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-full w-2/3 animate-pulse-subtle" />
            </div>
          </div>
        </div>
      )}

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 px-4 lg:px-8 py-6 max-w-7xl mx-auto w-full space-y-6">
        {!hasPlan && messages.length === 0 ? (
          <EmptyStateBanner onProcessBatch={handleProcessBatch} />
        ) : (
          <>
            {activeTab === 'overview' && (
              <OverviewSection
                summary={stateSummary}
                setActiveTab={setActiveTab}
                setPlanningSubTab={setPlanningSubTab}
              />
            )}

            {activeTab === 'messages' && (
              <MessagesSection
                messages={messages}
                onAddSingleMessage={handleAddSingleMessage}
                newSender={newSender}
                setNewSender={setNewSender}
                newContent={newContent}
                setNewContent={setNewContent}
                updateFeedback={updateFeedback}
                dynamicPresets={dynamicPresets}
                applyPreset={applyPreset}
              />
            )}

            {activeTab === 'planning' && (
              <PlanningSection
                plan={plan}
                metadata={metadata}
                subTab={planningSubTab}
                setSubTab={setPlanningSubTab}
              />
            )}

            {activeTab === 'trace' && (
              <TraceSection
                traces={traces}
                tokenUsage={tokenUsage}
                totalCalls={stateSummary?.totalModelCalls || 0}
                onSelectTrace={(t) => setSelectedTrace(t)}
                rejectedMessages={rejectedMessages}
              />
            )}

            {activeTab === 'conflicts' && (
              <ConflictsSection
                conflicts={conflicts}
                rejectedMessages={rejectedMessages}
              />
            )}
          </>
        )}
      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 text-slate-500 text-xs py-4 px-4 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <span>Mind to Machine AI Hackathon Planning System</span>
          <span>•</span>
          <span className="font-mono text-slate-400">Islamabad, Pakistan</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>Total Tokens: <strong className="text-slate-300 font-mono">{tokenUsage.totalTokens?.toLocaleString()}</strong></span>
          <span>•</span>
          <span>Model Calls: <strong className="text-slate-300 font-mono">{stateSummary?.totalModelCalls || 0}</strong></span>
        </div>
      </footer>

      {/* SETTINGS MODAL */}
      {settingsOpen && (
        <div className="fixed inset-0 modal-overlay z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-6 max-w-md w-full space-y-5 border border-slate-700 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Icons.Settings size={18} className="text-indigo-400" />
                AI Model & API Configuration
              </h3>
              <button
                onClick={() => setSettingsOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Google Gemini API Key
                </label>
                <input
                  type="password"
                  placeholder="AIzaSy... (leave empty to use local smart engine)"
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono text-xs"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Optional. If omitted, the system executes deterministic NLP agent heuristics with exact token counts.
                </p>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Model Selector
                </label>
                <select
                  value={modelSelect}
                  onChange={(e) => setModelSelect(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-indigo-500 font-mono text-xs"
                >
                  <option value="gemini-2.0-flash">gemini-2.0-flash (Recommended)</option>
                  <option value="gemini-1.5-flash">gemini-1.5-flash</option>
                  <option value="gemini-2.5-flash">gemini-2.5-flash</option>
                </select>
              </div>

              {settingsSuccess && (
                <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs">
                  {settingsSuccess}
                </div>
              )}

              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSettingsOpen(false)}
                  className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium shadow-md shadow-indigo-600/30"
                >
                  Save Configuration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TRACE INSPECTOR MODAL */}
      {selectedTrace && (
        <div className="fixed inset-0 modal-overlay z-50 flex items-center justify-center p-4">
          <div className="glass-panel p-6 max-w-3xl w-full max-h-[85vh] flex flex-col space-y-4 border border-indigo-500/30 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-xs font-mono font-bold">
                  Call #{selectedTrace.callNumber}
                </span>
                <span className="text-xs uppercase px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-semibold">
                  {selectedTrace.areaTag}
                </span>
                <span className="text-xs text-slate-400 font-mono">{selectedTrace.model}</span>
              </div>
              <button
                onClick={() => setSelectedTrace(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {/* Token Stats Bar */}
            <div className="grid grid-cols-3 gap-2 bg-slate-900/80 p-3 rounded-lg border border-slate-800 text-center font-mono text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Input Tokens</span>
                <span className="text-indigo-400 font-bold">{selectedTrace.inputTokens?.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Output Tokens</span>
                <span className="text-cyan-400 font-bold">{selectedTrace.outputTokens?.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase">Total Tokens</span>
                <span className="text-emerald-400 font-bold">{selectedTrace.totalTokens?.toLocaleString()}</span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
              <div>
                <h4 className="text-slate-400 font-bold mb-1.5 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <Icons.ArrowUpRight size={14} className="text-indigo-400" />
                  Prompt Sent to Model
                </h4>
                <pre className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 whitespace-pre-wrap font-mono leading-relaxed max-h-60 overflow-y-auto">
                  {selectedTrace.input}
                </pre>
              </div>

              <div>
                <h4 className="text-slate-400 font-bold mb-1.5 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <Icons.Sparkles size={14} className="text-cyan-400" />
                  Model Output / Response
                </h4>
                <pre className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-emerald-300 whitespace-pre-wrap font-mono leading-relaxed max-h-60 overflow-y-auto">
                  {selectedTrace.output}
                </pre>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedTrace(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// -----------------------------------------------------------------
// EMPTY STATE COMPONENT
// -----------------------------------------------------------------
function EmptyStateBanner({ onProcessBatch }) {
  return (
    <div className="glass-panel p-10 text-center space-y-6 max-w-3xl mx-auto my-12 border-indigo-500/20">
      <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 border border-indigo-500/30 mx-auto flex items-center justify-center text-indigo-400 shadow-xl shadow-indigo-500/10">
        <Icons.Brain size={32} />
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight text-white">
          Autonomous Hackathon Operations System
        </h2>
        <p className="text-sm text-slate-400 max-w-xl mx-auto">
          Read multi-source communications (emails, WhatsApp, notices) in English and Roman Urdu, resolve conflicting quotes, calculate catering and judge capacity, and generate a valid 4-hour event plan.
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
        <button
          onClick={() => onProcessBatch(1)}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/25 flex items-center gap-2 transition transform hover:-translate-y-0.5"
        >
          <Icons.Zap size={16} />
          Load Sample Pack 1 (Standard 12 Messages)
        </button>

        <button
          onClick={() => onProcessBatch(2)}
          className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 transition"
        >
          <Icons.Calendar size={16} />
          Load Sample Pack 2 (Evening Slot, 400k PKR)
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left pt-6 border-t border-slate-800/80 text-xs">
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
          <span className="text-indigo-400 font-bold block mb-1">150 Students</span>
          <span className="text-slate-400 text-[11px]">50 teams of 3 participants in Islamabad</span>
        </div>
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
          <span className="text-purple-400 font-bold block mb-1">Strict 4 Hours</span>
          <span className="text-slate-400 text-[11px]">Opening, prayer break, freeze & judging</span>
        </div>
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
          <span className="text-cyan-400 font-bold block mb-1">Zero Under-Catering</span>
          <span className="text-slate-400 text-[11px]">Enforces food order &gt;= total headcount</span>
        </div>
        <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800">
          <span className="text-emerald-400 font-bold block mb-1">Audit Trace</span>
          <span className="text-slate-400 text-[11px]">Exact token counts & sequential call logs</span>
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 1. OVERVIEW DASHBOARD SECTION
// -----------------------------------------------------------------
function OverviewSection({ summary, setActiveTab, setPlanningSubTab }) {
  const m = summary.metadata;
  const p = summary.plan;
  const b = p.budget;
  const v = p.venue;
  const s = p.schedule;
  const f = p.food;
  const j = p.judging;
  const val = summary.overallValidity;

  const budgetUsedPct = b.utilizationPercentage || 0;

  return (
    <div className="space-y-6">
      {/* TOP KPI BAR */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="glass-panel p-4 space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.MapPin size={14} className="text-indigo-400" />
            Location
          </span>
          <p className="text-base font-bold text-white tracking-tight">{m.location}</p>
          <span className="text-[11px] text-slate-500 font-mono">Physical Event</span>
        </div>

        <div className="glass-panel p-4 space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Users size={14} className="text-purple-400" />
            Participants
          </span>
          <p className="text-base font-bold text-white tracking-tight">150 Students</p>
          <span className="text-[11px] text-slate-500 font-mono">50 Teams of 3</span>
        </div>

        <div className="glass-panel p-4 space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Clock size={14} className="text-cyan-400" />
            Duration
          </span>
          <p className="text-base font-bold text-white tracking-tight">4.0 Hours</p>
          <span className="text-[11px] text-slate-500 font-mono">{s.startTime} - {s.endTime}</span>
        </div>

        <div className="glass-panel p-4 space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.DollarSign size={14} className="text-emerald-400" />
            Approved Budget
          </span>
          <p className="text-base font-bold text-white tracking-tight font-mono">
            {b.totalApprovedBudget?.toLocaleString()} PKR
          </p>
          <span className="text-[11px] text-emerald-400 font-mono">Ceiling limit</span>
        </div>

        <div className="glass-panel p-4 space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Activity size={14} className="text-amber-400" />
            Expenditure
          </span>
          <p className="text-base font-bold text-white tracking-tight font-mono">
            {b.totalExpenditure?.toLocaleString()} PKR
          </p>
          <span className="text-[11px] text-slate-400 font-mono">{budgetUsedPct}% utilized</span>
        </div>

        <div className="glass-panel p-4 space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Shield size={14} className="text-indigo-400" />
            Remaining Buffer
          </span>
          <p className={`text-base font-bold tracking-tight font-mono ${b.remainingBudget >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {b.remainingBudget?.toLocaleString()} PKR
          </p>
          <span className="text-[11px] text-slate-500 font-mono">
            {b.remainingBudget >= 0 ? 'Solvent buffer' : 'Deficit!'}
          </span>
        </div>
      </div>

      {/* PLAN VALIDITY BANNER */}
      <div className={`p-4 rounded-xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
        val.isValid
          ? 'bg-emerald-500/10 border-emerald-500/30'
          : 'bg-red-500/10 border-red-500/30'
      }`}>
        <div className="flex items-center space-x-3.5">
          <div className={`p-2.5 rounded-xl ${val.isValid ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
            {val.isValid ? <Icons.CheckCircle2 size={24} /> : <Icons.AlertTriangle size={24} />}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-bold text-white">
                {val.isValid ? 'Event Plan Officially Validated' : 'Plan Validation Blocked'}
              </h3>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                val.isValid ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
              }`}>
                STATUS: {val.status}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              {val.isValid
                ? 'All five planning constraints (Venue seating & generator, 4-hour timeline, complete catering headcount, judge sufficiency, and budget ceiling) are met.'
                : (val.errors?.[0] || 'One or more constraints violate hackathon operational guidelines.')
              }
            </p>
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('planning')}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            Inspect 5 Planning Areas →
          </button>
        </div>
      </div>

      {/* FIVE DOMAIN SUMMARY CARDS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
            <Icons.Cpu size={16} className="text-indigo-400" />
            Operational Domain Summaries
          </h3>
          <span className="text-xs text-slate-500">Autonomous multi-agent synthesis</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 1. Venue Summary */}
          <div
            onClick={() => { setActiveTab('planning'); setPlanningSubTab('venue'); }}
            className="glass-panel-interactive p-4 space-y-3 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Icons.MapPin size={15} /> Venue Allocation
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {v.status}
              </span>
            </div>
            <div>
              <p className="text-sm font-bold text-white">{v.recommended || 'No venue selected'}</p>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{v.reason}</p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Cap: <strong className="text-white">{v.seatingCapacity}</strong> seats</span>
              <span>Rent: <strong className="text-white">{v.rentalPrice?.toLocaleString()} PKR</strong></span>
              <span className="text-emerald-400">⚡ Generator</span>
            </div>
          </div>

          {/* 2. Schedule Summary */}
          <div
            onClick={() => { setActiveTab('planning'); setPlanningSubTab('schedule'); }}
            className="glass-panel-interactive p-4 space-y-3 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Icons.Clock size={15} /> Schedule Timeline
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                4 HOURS EXACT
              </span>
            </div>
            <div>
              <p className="text-sm font-bold text-white">{s.startTime} - {s.endTime} PKT</p>
              <p className="text-xs text-slate-400 mt-1">
                Prayer: <span className="text-slate-300">{s.prayerBreakTime}</span> • Freeze: <span className="text-slate-300">{s.codeFreezeTime}</span>
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Phases: <strong className="text-white">{s.timeline?.length}</strong> blocks</span>
              <span>Judging: <strong className="text-white">{s.judgingWindow}</strong></span>
            </div>
          </div>

          {/* 3. Food Summary */}
          <div
            onClick={() => { setActiveTab('planning'); setPlanningSubTab('food'); }}
            className="glass-panel-interactive p-4 space-y-3 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Icons.Utensils size={15} /> Catering & Food
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                100% HEADCOUNT
              </span>
            </div>
            <div>
              <p className="text-sm font-bold text-white">{f.selectedMeal}</p>
              <p className="text-xs text-slate-400 mt-1">
                Strictly feeding {f.headcountToFeed} attendees ({m.targetParticipants} students + {m.organizersCount} staff + judges)
              </p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Unit: <strong className="text-white">{f.pricePerPerson} PKR</strong></span>
              <span>Deliv: <strong className="text-white">{f.deliveryCharges?.toLocaleString()} PKR</strong></span>
              <span>Total: <strong className="text-cyan-400">{f.totalFoodCost?.toLocaleString()} PKR</strong></span>
            </div>
          </div>

          {/* 4. Judging Summary */}
          <div
            onClick={() => { setActiveTab('planning'); setPlanningSubTab('judging'); }}
            className="glass-panel-interactive p-4 space-y-3 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Icons.Award size={15} /> Judging Capacity
              </span>
              <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold border ${
                j.isCapacitySufficient
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                  : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
              }`}>
                {j.isCapacitySufficient ? 'SUFFICIENT' : 'ALERT'}
              </span>
            </div>
            <div>
              <p className="text-sm font-bold text-white">50 Teams ÷ {j.availableJudges} Judges</p>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{j.explanation}</p>
            </div>
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Time/Team: <strong className="text-white">{j.timeRequiredPerTeam}m</strong></span>
              <span>Honorarium: <strong className="text-white">{j.totalHonorarium?.toLocaleString()} PKR</strong></span>
            </div>
          </div>

          {/* 5. Budget Summary */}
          <div
            onClick={() => { setActiveTab('planning'); setPlanningSubTab('budget'); }}
            className="glass-panel-interactive p-4 space-y-3 cursor-pointer md:col-span-2 lg:col-span-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider">
                <Icons.DollarSign size={15} /> Financial Budget Breakdown
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                APPROVED & BALANCED
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div>
                <span className="text-slate-500 block text-[10px]">Venue</span>
                <span className="text-white font-bold">{b.breakdown?.venue?.toLocaleString()} PKR</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Food & Delivery</span>
                <span className="text-white font-bold">{b.breakdown?.food?.toLocaleString()} PKR</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Prizes</span>
                <span className="text-white font-bold">{b.breakdown?.prizes?.toLocaleString()} PKR</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Honorarium</span>
                <span className="text-white font-bold">{b.breakdown?.judgesHonorarium?.toLocaleString()} PKR</span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Budget Utilization ({budgetUsedPct}%)</span>
                <span>Remaining: {b.remainingBudget?.toLocaleString()} PKR</span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    budgetUsedPct > 100 ? 'bg-red-500' : 'bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400'
                  }`}
                  style={{ width: `${Math.min(100, budgetUsedPct)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 2. MESSAGE PROCESSING SECTION
// -----------------------------------------------------------------
function MessagesSection({
  messages,
  onAddSingleMessage,
  newSender,
  setNewSender,
  newContent,
  setNewContent,
  updateFeedback,
  dynamicPresets,
  applyPreset
}) {
  const [filterLang, setFilterLang] = useState('all');

  const filtered = messages.filter(m => {
    if (filterLang === 'urdu') return m.isRomanUrdu;
    if (filterLang === 'english') return !m.isRomanUrdu;
    return true;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* LEFT: MESSAGE CARDS LIST (2 COLS) */}
      <div className="lg:col-span-2 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Icons.MessageSquare size={16} className="text-indigo-400" />
              Processed Messages ({filtered.length} / {messages.length})
            </h3>
            <p className="text-xs text-slate-400">English and Roman Urdu communications parsed with source references.</p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setFilterLang('all')}
              className={`px-2.5 py-1 rounded ${filterLang === 'all' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400'}`}
            >
              All
            </button>
            <button
              onClick={() => setFilterLang('urdu')}
              className={`px-2.5 py-1 rounded ${filterLang === 'urdu' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400'}`}
            >
              Roman Urdu
            </button>
            <button
              onClick={() => setFilterLang('english')}
              className={`px-2.5 py-1 rounded ${filterLang === 'english' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400'}`}
            >
              English
            </button>
          </div>
        </div>

        {/* Message Feed */}
        <div className="space-y-3 max-h-[750px] overflow-y-auto pr-1">
          {filtered.map(msg => (
            <div
              key={msg.id}
              className={`glass-panel p-4 space-y-2.5 border transition ${
                msg.status === 'rejected'
                  ? 'border-red-500/40 bg-red-950/20'
                  : 'border-slate-800/80 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-slate-700">
                    [{msg.id.toUpperCase()}]
                  </span>
                  <strong className="text-xs text-white">{msg.sender}</strong>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                    msg.isRomanUrdu
                      ? 'bg-purple-500/10 text-purple-300 border border-purple-500/20'
                      : 'bg-blue-500/10 text-blue-300 border border-blue-500/20'
                  }`}>
                    {msg.language}
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                    msg.status === 'rejected'
                      ? 'bg-red-500/20 text-red-300'
                      : 'bg-emerald-500/10 text-emerald-400'
                  }`}>
                    {msg.status}
                  </span>
                </div>
              </div>

              {msg.subject && (
                <p className="text-xs font-semibold text-slate-300">
                  Subject: <span className="text-slate-200">{msg.subject}</span>
                </p>
              )}

              <p className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed bg-slate-950/50 p-2.5 rounded-lg border border-slate-800/60 font-sans">
                {msg.content}
              </p>

              {/* Extracted Facts Pills */}
              {msg.extractedInfo && msg.extractedInfo.length > 0 && (
                <div className="pt-1 flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] text-slate-500 uppercase font-mono">Extracted Facts:</span>
                  {msg.extractedInfo.map((info, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                    >
                      {info.entity || info.category}
                    </span>
                  ))}
                </div>
              )}

              {msg.validationReason && (
                <div className={`p-2 rounded text-[11px] ${
                  msg.status === 'rejected' ? 'bg-red-500/15 text-red-300 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-300'
                }`}>
                  <strong>Agent Verdict:</strong> {msg.validationReason}
                </div>
              )}

              <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono pt-1">
                <span>Date: {msg.date}</span>
                <span>Ref: #{msg.messageNumber}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RIGHT: DYNAMIC UPDATE FORM (1 COL) */}
      <div className="space-y-4">
        <div className="glass-panel p-5 space-y-4 border-indigo-500/20 sticky top-20">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Icons.Plus size={16} className="text-indigo-400" />
              Dynamic Message Submission
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Test dynamic incremental updates. The system calls ONLY affected agents (maximum 5 model calls).
            </p>
          </div>

          {/* Quick Preset Buttons */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-mono uppercase text-slate-400 block font-bold">
              Test Presets (Click to Load):
            </span>
            <div className="flex flex-col gap-1.5">
              {dynamicPresets.map(preset => (
                <button
                  key={preset.id}
                  onClick={() => applyPreset(preset)}
                  className="text-left p-2 rounded-lg bg-slate-900/80 hover:bg-indigo-600/20 border border-slate-800 hover:border-indigo-500/40 text-xs transition text-slate-300 group"
                >
                  <span className="font-semibold text-white group-hover:text-indigo-300 block">
                    {preset.title}
                  </span>
                  <span className="text-[10px] text-slate-400 line-clamp-1">
                    {preset.description}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={onAddSingleMessage} className="space-y-3 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-slate-300 text-xs font-medium mb-1">Sender</label>
              <input
                type="text"
                placeholder="e.g. Catering Coordinator (Fatima)"
                value={newSender}
                onChange={(e) => setNewSender(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 text-xs font-medium mb-1">Message Content (English or Roman Urdu)</label>
              <textarea
                rows={4}
                placeholder="Enter message text with new quote, constraint, or update..."
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-indigo-500 resize-none font-sans"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 flex items-center justify-center gap-1.5 transition"
            >
              <Icons.Zap size={14} />
              Process Message & Update Plan
            </button>
          </form>

          {/* Feedback banner */}
          {updateFeedback && (
            <div className={`p-3 rounded-lg border text-xs space-y-1 ${
              updateFeedback.accepted
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-red-500/10 border-red-500/30 text-red-300'
            }`}>
              <div className="flex items-center justify-between font-bold">
                <span>{updateFeedback.accepted ? 'Update Accepted' : 'Proposal Rejected'}</span>
                <span className="font-mono text-[10px]">Calls: {updateFeedback.modelCallsUsed} / 5</span>
              </div>
              <p className="text-[11px] leading-relaxed">{updateFeedback.message}</p>
              {updateFeedback.affectedAreas?.length > 0 && (
                <p className="text-[10px] text-slate-400 font-mono">
                  Affected areas: {updateFeedback.affectedAreas.join(', ')}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 3. PLANNING SECTIONS (5 DOMAINS)
// -----------------------------------------------------------------
function PlanningSection({ plan, metadata, subTab, setSubTab }) {
  const v = plan.venue;
  const s = plan.schedule;
  const f = plan.food;
  const j = plan.judging;
  const b = plan.budget;

  const tabs = [
    { id: 'venue', label: '1. Venue Allocation', icon: Icons.MapPin },
    { id: 'schedule', label: '2. 4-Hour Schedule', icon: Icons.Clock },
    { id: 'food', label: '3. Catering & Food', icon: Icons.Utensils },
    { id: 'judging', label: '4. Judging Allocation', icon: Icons.Award },
    { id: 'budget', label: '5. Budget & Finance', icon: Icons.DollarSign }
  ];

  return (
    <div className="space-y-5">
      {/* Sub Tabs */}
      <div className="flex space-x-1.5 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 overflow-x-auto text-xs font-semibold">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition whitespace-nowrap ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Icon size={14} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. VENUE TAB */}
      {subTab === 'venue' && (
        <div className="space-y-4">
          <div className="glass-panel p-5 space-y-4 border-indigo-500/20">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs uppercase font-mono text-indigo-400 font-bold">Selected Recommendation</span>
                <h3 className="text-xl font-bold text-white mt-0.5">{v.recommended}</h3>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">{v.reason}</p>
              </div>
              <div className="text-right font-mono">
                <span className="text-xs text-slate-400 block">Rental Cost</span>
                <span className="text-xl font-bold text-emerald-400">{v.rentalPrice?.toLocaleString()} PKR</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Seating Capacity</span>
                <span className="text-white text-base font-bold">{v.seatingCapacity} Seats</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Headcount to Fit</span>
                <span className="text-white text-base font-bold">{metadata.totalHeadcount} Attendees</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Capacity Buffer</span>
                <span className="text-emerald-400 text-base font-bold">+{v.seatingCapacity - metadata.totalHeadcount} Seats</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Generator Status</span>
                <span className="text-cyan-400 text-base font-bold">Active Industrial Backup</span>
              </div>
            </div>
          </div>

          {/* Venue Options Comparison */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider">All Evaluated Venue Candidates</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(v.options || []).map((opt, idx) => {
                const isSelected = opt.name === v.recommended;
                return (
                  <div
                    key={idx}
                    className={`glass-panel p-4 space-y-2 border transition ${
                      isSelected ? 'border-indigo-500 bg-indigo-950/20' : 'border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-bold text-white">{opt.name}</h5>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        opt.isEligible ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                      }`}>
                        {opt.isEligible ? 'ELIGIBLE' : 'DISQUALIFIED'}
                      </span>
                    </div>

                    <div className="text-xs font-mono space-y-1 text-slate-300">
                      <div className="flex justify-between">
                        <span>Capacity:</span>
                        <strong className={opt.capacity >= metadata.totalHeadcount ? 'text-white' : 'text-red-400'}>
                          {opt.capacity} seats
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Rent:</span>
                        <strong className="text-white">{opt.rentalCost?.toLocaleString()} PKR</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Generator:</span>
                        <strong className={opt.hasGenerator ? 'text-emerald-400' : 'text-red-400'}>
                          {opt.hasGenerator ? 'Yes' : 'No (Broken/None)'}
                        </strong>
                      </div>
                    </div>

                    {!opt.isEligible && (
                      <p className="text-[11px] text-red-300/90 pt-1 border-t border-slate-800">
                        {opt.eligibilityStatus}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 2. SCHEDULE TAB */}
      {subTab === 'schedule' && (
        <div className="space-y-4">
          <div className="glass-panel p-4 flex flex-wrap items-center justify-between gap-3 text-xs font-mono border-purple-500/20">
            <div>
              <span className="text-slate-400 block text-[10px]">Total Schedule Duration</span>
              <span className="text-white font-bold text-base">{s.durationHours} Hours (240 Minutes)</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Start - End Time</span>
              <span className="text-purple-300 font-bold text-base">{s.startTime} - {s.endTime} PKT</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Prayer Break</span>
              <span className="text-cyan-300 font-bold text-base">{s.prayerBreakTime}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Code Freeze</span>
              <span className="text-amber-300 font-bold text-base">{s.codeFreezeTime}</span>
            </div>
          </div>

          {/* Timeline Blocks */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider">Sequential Milestone Schedule</h4>
            <div className="space-y-2.5">
              {(s.timeline || []).map((item, idx) => {
                let badgeColor = 'bg-blue-500/10 text-blue-300 border-blue-500/30';
                if (item.type === 'prayer') badgeColor = 'bg-purple-500/10 text-purple-300 border-purple-500/30';
                if (item.type === 'code_freeze') badgeColor = 'bg-red-500/10 text-red-300 border-red-500/30';
                if (item.type === 'judging') badgeColor = 'bg-amber-500/10 text-amber-300 border-amber-500/30';

                return (
                  <div key={idx} className="glass-panel p-3.5 flex items-start justify-between gap-3 border-slate-800 hover:border-slate-700 transition">
                    <div className="flex items-start space-x-3.5">
                      <div className="text-center font-mono w-24 pt-0.5">
                        <span className="text-xs font-bold text-white block">{item.startTime} - {item.endTime}</span>
                        <span className="text-[10px] text-slate-500">{item.durationMinutes} mins</span>
                      </div>
                      <div className="border-l border-slate-800 pl-3.5 space-y-0.5">
                        <div className="flex items-center space-x-2">
                          <h5 className="text-xs font-bold text-white">{item.phase}</h5>
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${badgeColor}`}>
                            {item.type}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400">{item.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. FOOD TAB */}
      {subTab === 'food' && (
        <div className="space-y-4">
          <div className="glass-panel p-5 space-y-4 border-cyan-500/20">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs uppercase font-mono text-cyan-400 font-bold">Selected Catering Vendor</span>
                <h3 className="text-xl font-bold text-white mt-0.5">{f.selectedMeal}</h3>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">{f.notes}</p>
              </div>
              <div className="text-right font-mono">
                <span className="text-xs text-slate-400 block">Total Catering Cost</span>
                <span className="text-xl font-bold text-cyan-400">{f.totalFoodCost?.toLocaleString()} PKR</span>
              </div>
            </div>

            {/* Arithmetic Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Headcount to Feed</span>
                <span className="text-white text-base font-bold">{f.headcountToFeed} Attendees</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Boxes Ordered</span>
                <span className="text-emerald-400 text-base font-bold">{f.orderQuantity} Boxes</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Price per Person</span>
                <span className="text-white text-base font-bold">{f.pricePerPerson} PKR</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Delivery Charge</span>
                <span className="text-white text-base font-bold">{f.deliveryCharges?.toLocaleString()} PKR</span>
              </div>
            </div>

            {/* Strict Constraint Alert */}
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
              <Icons.Shield size={16} />
              <span>
                <strong>Under-Catering Policy Enforced:</strong> Order quantity ({f.orderQuantity}) strictly matches total headcount ({f.headcountToFeed}). Any under-ordering proposal is automatically rejected.
              </span>
            </div>
          </div>

          {/* Other Catering Quotes */}
          {f.availableOptions?.length > 1 && (
            <div className="space-y-2">
              <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider">All Received Catering Quotes</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {f.availableOptions.map((opt, idx) => (
                  <div key={idx} className="glass-panel p-3.5 space-y-1.5 text-xs font-mono border-slate-800">
                    <span className="font-bold text-white block">{opt.vendor}</span>
                    <div className="flex justify-between text-slate-400 text-[11px]">
                      <span>Rate:</span>
                      <strong className="text-white">{opt.pricePerPerson} PKR / person</strong>
                    </div>
                    <div className="flex justify-between text-slate-400 text-[11px]">
                      <span>Delivery:</span>
                      <strong className="text-white">{opt.deliveryFee?.toLocaleString()} PKR</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. JUDGING TAB */}
      {subTab === 'judging' && (
        <div className="space-y-4">
          <div className="glass-panel p-5 space-y-4 border-amber-500/20">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs uppercase font-mono text-amber-400 font-bold">Judging Capacity & Workload</span>
                <h3 className="text-xl font-bold text-white mt-0.5">50 Teams Parallel Evaluation</h3>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">{j.explanation}</p>
              </div>
              <div className="text-right font-mono">
                <span className="text-xs text-slate-400 block">Total Honorarium</span>
                <span className="text-xl font-bold text-amber-400">{j.totalHonorarium?.toLocaleString()} PKR</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Total Teams</span>
                <span className="text-white text-base font-bold">{j.totalTeams} Teams</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Demo Time / Team</span>
                <span className="text-white text-base font-bold">{j.timeRequiredPerTeam} Minutes</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Confirmed Judges</span>
                <span className="text-emerald-400 text-base font-bold">{j.availableJudges} Judges</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Honorarium / Judge</span>
                <span className="text-white text-base font-bold">{j.honorariumPerJudge?.toLocaleString()} PKR</span>
              </div>
            </div>
          </div>

          {/* Judge Team Allocation Table */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider">Parallel Judge Track Assignments</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {(j.allocation || []).map((alloc, idx) => (
                <div key={idx} className="glass-panel p-3.5 space-y-1.5 border-slate-800 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-300">Track #{alloc.judgeNumber}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {alloc.assignedTeamCount} Teams
                    </span>
                  </div>
                  <p className="text-xs text-white font-sans font-semibold">{alloc.judgeName}</p>
                  <div className="flex justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                    <span>{alloc.assignedTeamRange}</span>
                    <span>~{alloc.estimatedTimeMinutes} mins</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. BUDGET TAB */}
      {subTab === 'budget' && (
        <div className="space-y-4">
          <div className="glass-panel p-5 space-y-4 border-emerald-500/20">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs uppercase font-mono text-emerald-400 font-bold">Financial Feasibility Status</span>
                <h3 className="text-xl font-bold text-white mt-0.5">
                  {b.isWithinBudget ? 'Budget Approved & Solvent' : 'Over-Budget Alert!'}
                </h3>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">{b.notes}</p>
              </div>
              <div className="text-right font-mono">
                <span className="text-xs text-slate-400 block">Remaining Balance</span>
                <span className={`text-xl font-bold ${b.remainingBudget >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {b.remainingBudget?.toLocaleString()} PKR
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-800 text-xs font-mono text-center">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Approved Ceiling</span>
                <span className="text-white text-base font-bold">{b.totalApprovedBudget?.toLocaleString()} PKR</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Total Projected Cost</span>
                <span className="text-amber-400 text-base font-bold">{b.totalExpenditure?.toLocaleString()} PKR</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Budget Utilization</span>
                <span className="text-cyan-400 text-base font-bold">{b.utilizationPercentage}%</span>
              </div>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="space-y-2">
            <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider">Complete Line-Item Expenditure</h4>
            <div className="glass-panel overflow-hidden border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-4">Expense Item</th>
                    <th className="py-2.5 px-4">Category</th>
                    <th className="py-2.5 px-4">Operational Rationale</th>
                    <th className="py-2.5 px-4 text-right">Cost (PKR)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 font-mono">
                  {(b.lineItems || []).map((line, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/50">
                      <td className="py-2.5 px-4 font-bold text-white font-sans">{line.item}</td>
                      <td className="py-2.5 px-4 text-slate-400 text-[11px]">{line.category}</td>
                      <td className="py-2.5 px-4 text-slate-300 text-[11px] font-sans">{line.notes}</td>
                      <td className="py-2.5 px-4 text-right font-bold text-white">{line.cost?.toLocaleString()}</td>
                    </tr>
                  ))}
                  <tr className="bg-slate-900/90 font-bold text-white border-t-2 border-slate-700">
                    <td colSpan={3} className="py-3 px-4 font-sans text-sm">TOTAL EXPENDITURE</td>
                    <td className="py-3 px-4 text-right text-sm text-emerald-400">{b.totalExpenditure?.toLocaleString()} PKR</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// -----------------------------------------------------------------
// 4. MODEL CALL TRACE SECTION (MANDATORY REQUIREMENT 6)
// -----------------------------------------------------------------
function TraceSection({ traces, tokenUsage, totalCalls, onSelectTrace, rejectedMessages }) {
  return (
    <div className="space-y-6">
      {/* Top Token Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-panel p-4 font-mono space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Cpu size={14} className="text-indigo-400" />
            Total Model Invocations
          </span>
          <p className="text-2xl font-bold text-white">{totalCalls}</p>
          <span className="text-[10px] text-slate-500">Targeted Agent Calls</span>
        </div>

        <div className="glass-panel p-4 font-mono space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.ArrowUpRight size={14} className="text-purple-400" />
            Input Prompt Tokens
          </span>
          <p className="text-2xl font-bold text-purple-300">{tokenUsage.inputTokens?.toLocaleString()}</p>
          <span className="text-[10px] text-slate-500">Prompts & contexts</span>
        </div>

        <div className="glass-panel p-4 font-mono space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Sparkles size={14} className="text-cyan-400" />
            Output Response Tokens
          </span>
          <p className="text-2xl font-bold text-cyan-300">{tokenUsage.outputTokens?.toLocaleString()}</p>
          <span className="text-[10px] text-slate-500">Agent responses</span>
        </div>

        <div className="glass-panel p-4 font-mono space-y-1">
          <span className="text-slate-400 text-xs flex items-center gap-1.5">
            <Icons.Activity size={14} className="text-emerald-400" />
            Cumulative Token Usage
          </span>
          <p className="text-2xl font-bold text-emerald-400">{tokenUsage.totalTokens?.toLocaleString()}</p>
          <span className="text-[10px] text-slate-500">Exact token telemetry</span>
        </div>
      </div>

      {/* Execution Trace Table */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Icons.Activity size={16} className="text-indigo-400" />
            Sequential AI Execution Trace Audit Log
          </h3>
          <span className="text-xs text-slate-500">Click any row to inspect complete prompt and model output</span>
        </div>

        <div className="glass-panel overflow-hidden border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4 w-12 text-center">#</th>
                <th className="py-2.5 px-4">Area Tag</th>
                <th className="py-2.5 px-4">Model Engine</th>
                <th className="py-2.5 px-4 text-right">In Tokens</th>
                <th className="py-2.5 px-4 text-right">Out Tokens</th>
                <th className="py-2.5 px-4 text-right">Total Tokens</th>
                <th className="py-2.5 px-4 text-center">Inspector</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              {traces.map((trace) => {
                let badgeColor = 'bg-blue-500/10 text-blue-300 border-blue-500/20';
                if (trace.areaTag === 'reading') badgeColor = 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20';
                if (trace.areaTag === 'venue') badgeColor = 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20';
                if (trace.areaTag === 'schedule') badgeColor = 'bg-purple-500/10 text-purple-300 border-purple-500/20';
                if (trace.areaTag === 'food') badgeColor = 'bg-amber-500/10 text-amber-300 border-amber-500/20';
                if (trace.areaTag === 'judging') badgeColor = 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20';
                if (trace.areaTag === 'budget') badgeColor = 'bg-rose-500/10 text-rose-300 border-rose-500/20';

                return (
                  <tr
                    key={trace.callNumber}
                    onClick={() => onSelectTrace(trace)}
                    className="hover:bg-slate-800/60 cursor-pointer transition"
                  >
                    <td className="py-2.5 px-4 text-center font-bold text-slate-300">
                      {trace.callNumber}
                    </td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${badgeColor}`}>
                        {trace.areaTag}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-300 text-[11px]">
                      {trace.model}
                    </td>
                    <td className="py-2.5 px-4 text-right text-slate-400">
                      {trace.inputTokens?.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-right text-slate-400">
                      {trace.outputTokens?.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-right font-bold text-white">
                      {trace.totalTokens?.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      <button className="px-2.5 py-1 rounded bg-slate-800 hover:bg-indigo-600 text-[11px] text-slate-300 hover:text-white transition">
                        View
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 5. CONFLICTS & REJECTIONS LOG
// -----------------------------------------------------------------
function ConflictsSection({ conflicts, rejectedMessages }) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Icons.Shield size={16} className="text-amber-400" />
          Conflict Resolution & Rejection Audit Log
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Explicit record of outdated messages, rejected proposals, and constraint enforcement.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {conflicts.length === 0 ? (
          <div className="glass-panel p-8 text-center text-slate-400 text-xs">
            No conflicts recorded yet. All messages aligned cleanly with plan constraints.
          </div>
        ) : (
          conflicts.map(c => (
            <div
              key={c.id}
              className={`glass-panel p-4 space-y-2 border ${
                c.rejected ? 'border-red-500/40 bg-red-950/15' : 'border-amber-500/30 bg-amber-950/10'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                    c.rejected ? 'bg-red-500/20 text-red-300' : 'bg-amber-500/20 text-amber-300'
                  }`}>
                    {c.rejected ? 'REJECTED' : 'RESOLVED / OVERRIDE'}
                  </span>
                  <span className="text-xs font-mono text-slate-400">Ref: [{c.messageId}]</span>
                  <strong className="text-xs text-white">{c.type}</strong>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">{c.timestamp}</span>
              </div>

              <p className="text-xs text-slate-200">{c.description}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono pt-1">
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Attempted Change:</span>
                  <span className="text-slate-300">{c.attemptedChange}</span>
                </div>
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Resolution & Policy:</span>
                  <span className={c.rejected ? 'text-red-300' : 'text-emerald-300'}>{c.resolution}</span>
                </div>
              </div>

              {c.reason && (
                <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
                  <strong>Constraint Rationale:</strong> {c.reason}
                </p>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// Mount React Root
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
