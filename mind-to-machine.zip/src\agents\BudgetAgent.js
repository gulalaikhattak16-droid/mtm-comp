// src/agents/BudgetAgent.js

export class BudgetAgent {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;
  }

  async validateBudget(facts, domainPlans) {
    const budgetFacts = facts.filter(f => f.category === 'budget' || f.category === 'metadata');
    const promptText = `Validate the overall budget for Mind to Machine Hackathon.
Current domain costs:
- Venue Rental: ${domainPlans.venue?.rentalPrice || 0} PKR
- Food Catering: ${domainPlans.food?.totalFoodCost || 0} PKR
- Judges' Honorarium: ${domainPlans.judging?.totalHonorarium || 0} PKR

Budget Facts from messages:
${JSON.stringify(budgetFacts, null, 2)}

Calculate:
1. Approved budget ceiling.
2. Itemized expenditure (Venue, Food, Judges, Prizes, Internet, Printing, Other).
3. Total expenditure.
4. Remaining budget.
5. Utilization percentage.
6. Approval status (NEVER approve if expenditure > approved budget).
`;

    const systemInstruction = `You are the Budget & Financial Validation Agent. Compute deterministic financial totals and validate feasibility against approved funds. Return JSON.`;

    const result = await this.geminiService.generateContent({
      prompt: promptText,
      systemInstruction,
      areaTag: 'budget',
      fallbackHandler: () => this.validateBudgetDeterministic(budgetFacts, domainPlans)
    });

    let budgetPlan = null;
    try {
      const cleanJson = result.output.replace(/```json/g, '').replace(/```/g, '').trim();
      budgetPlan = JSON.parse(cleanJson);
    } catch {
      budgetPlan = this.validateBudgetDeterministic(budgetFacts, domainPlans);
    }

    // Record trace
    this.stateStore.recordTrace({
      model: result.model,
      areaTag: 'budget',
      input: result.input,
      output: result.output,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      totalTokens: result.totalTokens,
      isLiveApi: result.isLiveApi,
      note: result.note
    });

    this.stateStore.plan.budget = budgetPlan;
    return budgetPlan;
  }

  validateBudgetDeterministic(budgetFacts, domainPlans) {
    let approvedCeiling = 350000; // default if not extracted
    let prizes = 100000;
    let internet = 15000;
    let printing = 18000;
    let other = 12000;

    budgetFacts.forEach(bf => {
      const d = bf.details || {};
      if (d.budgetLimit) approvedCeiling = d.budgetLimit;
      if (d.prizes) prizes = d.prizes;
      if (d.internet) internet = d.internet;
      if (d.printing) printing = d.printing;
      if (d.other) other = d.other;

      // If there was an unauthorized extra activity (e.g. VR gaming or videography)
      if (d.extraActivityCost && d.extraActivityCost > 0) {
        this.stateStore.recordConflict({
          messageId: bf.sourceMessageId,
          type: 'UNAUTHORIZED_EXPENSE_REQUEST',
          description: `Sponsor or partner requested extra activity costing ${d.extraActivityCost.toLocaleString()} PKR`,
          attemptedChange: `Additional cost: +${d.extraActivityCost} PKR`,
          resolution: `Rejected. Expense is non-essential and would exceed or severely deplete the contingency budget.`,
          rejected: true,
          reason: `Requested addition (${d.extraActivityCost.toLocaleString()} PKR) was denied by event management to preserve budget solvency.`
        });
      }
    });

    const venueCost = domainPlans.venue?.rentalPrice || 0;
    const foodCost = domainPlans.food?.totalFoodCost || 0;
    const judgesCost = domainPlans.judging?.totalHonorarium || 0;

    const totalExpenditure = venueCost + foodCost + judgesCost + prizes + internet + printing + other;
    const remainingBudget = approvedCeiling - totalExpenditure;
    const utilizationPercentage = approvedCeiling > 0 ? Number(((totalExpenditure / approvedCeiling) * 100).toFixed(2)) : 0;
    
    // Strict rule: Never approve if expenditure exceeds budget
    const isApproved = totalExpenditure <= approvedCeiling;

    return {
      status: isApproved ? 'APPROVED' : 'REJECTED_OVER_BUDGET',
      isValid: isApproved,
      totalApprovedBudget: approvedCeiling,
      totalExpenditure,
      remainingBudget,
      utilizationPercentage,
      isWithinBudget: isApproved,
      breakdown: {
        venue: venueCost,
        food: foodCost,
        judgesHonorarium: judgesCost,
        prizes,
        internet,
        printing,
        other
      },
      lineItems: [
        { item: 'Venue Rental', cost: venueCost, category: 'Infrastructure', notes: domainPlans.venue?.recommended || 'Selected Venue' },
        { item: 'Catering & Food Delivery', cost: foodCost, category: 'Hospitality', notes: domainPlans.food?.selectedMeal || 'Full Headcount Catering' },
        { item: 'Judges\' Honorarium', cost: judgesCost, category: 'Evaluation', notes: `${domainPlans.judging?.availableJudges || 5} Judges @ ${domainPlans.judging?.honorariumPerJudge || 5000} PKR` },
        { item: 'Cash Prizes (1st, 2nd, 3rd)', cost: prizes, category: 'Awards', notes: 'Approved prize pool' },
        { item: 'Dedicated Fiber Internet Backup', cost: internet, category: 'Technical', notes: 'Redundant connection' },
        { item: 'Badges, Certificates & Printing', cost: printing, category: 'Logistics', notes: '150 participants + staff' },
        { item: 'First Aid, VIP Refreshments & Contingency', cost: other, category: 'Operations', notes: 'Safety and VIP kit' }
      ],
      notes: isApproved 
        ? `Budget is healthy. Total expenditure of ${totalExpenditure.toLocaleString()} PKR is within the ${approvedCeiling.toLocaleString()} PKR ceiling with ${remainingBudget.toLocaleString()} PKR (${(100 - utilizationPercentage).toFixed(1)}%) buffer remaining.`
        : `CRITICAL BUDGET DEFICIT: Total expenditure (${totalExpenditure.toLocaleString()} PKR) exceeds the approved ceiling of ${approvedCeiling.toLocaleString()} PKR by ${Math.abs(remainingBudget).toLocaleString()} PKR. Plan cannot be approved!`
    };
  }
}
