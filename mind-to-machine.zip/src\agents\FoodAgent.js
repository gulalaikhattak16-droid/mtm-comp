// src/agents/FoodAgent.js

export class FoodAgent {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;
  }

  async calculate(facts, totalHeadcount) {
    const foodFacts = facts.filter(f => f.category === 'food');
    const promptText = `Calculate catering requirements for Mind to Machine Hackathon.
Headcount to feed: Strictly ${totalHeadcount} people (participants + staff/mentors + judges).
CRITICAL RULE: Never accept an order quantity lower than ${totalHeadcount}. Reject any under-catering proposals.
Identify latest catering prices and delivery fees. Resolve outdated quotes.

Food Quotes and Messages:
${JSON.stringify(foodFacts, null, 2)}
`;

    const systemInstruction = `You are the Food & Catering Agent. Calculate the required meals and cost. Return JSON with meal options, selected option, unit price, delivery fee, and total cost. Enforce order quantity >= ${totalHeadcount}.`;

    const result = await this.geminiService.generateContent({
      prompt: promptText,
      systemInstruction,
      areaTag: 'food',
      fallbackHandler: () => this.calculateDeterministic(foodFacts, totalHeadcount)
    });

    let foodPlan = null;
    try {
      const cleanJson = result.output.replace(/```json/g, '').replace(/```/g, '').trim();
      foodPlan = JSON.parse(cleanJson);
    } catch {
      foodPlan = this.calculateDeterministic(foodFacts, totalHeadcount);
    }

    // Record trace
    this.stateStore.recordTrace({
      model: result.model,
      areaTag: 'food',
      input: result.input,
      output: result.output,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      totalTokens: result.totalTokens,
      isLiveApi: result.isLiveApi,
      note: result.note
    });

    this.stateStore.plan.food = foodPlan;
    return foodPlan;
  }

  calculateDeterministic(foodFacts, totalHeadcount) {
    // Process all food proposals and track price updates
    const mealOptions = [];
    const vendorMap = new Map();

    foodFacts.forEach(ff => {
      const d = ff.details || {};
      
      // If this was an under-order suggestion, record rejection
      if (d.isUnderOrderProposal) {
        this.stateStore.recordConflict({
          messageId: ff.sourceMessageId,
          type: 'UNDER_CATERING_ATTEMPT',
          description: `Suggestion to order only ${d.suggestedQuantity} boxes for ${totalHeadcount} people`,
          attemptedChange: `Order quantity: ${d.suggestedQuantity}`,
          resolution: `Rejected. In accordance with event policy, headcount is ${totalHeadcount}. Under-catering is strictly prohibited. Enforcing full order of ${totalHeadcount} boxes.`,
          rejected: true,
          reason: `Violates core constraint: Order quantity (${d.suggestedQuantity}) is less than total headcount (${totalHeadcount}). Every participant, mentor, and judge must receive a meal.`
        });
        return;
      }

      if (d.pricePerPerson) {
        const vendorKey = (d.vendor || 'Catering Vendor').toLowerCase();
        
        // Check if updating an existing vendor quote
        if (vendorMap.has(vendorKey)) {
          const oldQuote = vendorMap.get(vendorKey);
          this.stateStore.recordConflict({
            messageId: ff.sourceMessageId,
            type: 'CATERING_PRICE_UPDATE',
            description: `Price update for ${d.vendor}: ${oldQuote.pricePerPerson} PKR -> ${d.pricePerPerson} PKR`,
            attemptedChange: `Price per person: ${d.pricePerPerson} PKR, Delivery: ${d.deliveryFee} PKR`,
            resolution: `Accepted. Superseded previous quote of ${oldQuote.pricePerPerson} PKR with newer quote from message ${ff.sourceMessageId}.`,
            rejected: false,
            reason: `Newer vendor quote replaces older quote.`
          });
        }

        const quote = {
          vendor: d.vendor || 'Catering Vendor',
          pricePerPerson: d.pricePerPerson,
          deliveryFee: d.deliveryFee || 0,
          sourceMessageId: ff.sourceMessageId
        };

        vendorMap.set(vendorKey, quote);
        mealOptions.push(quote);
      }
    });

    // Pick best active meal option: lowest total cost = (headcount * price) + delivery
    let bestOption = null;
    let minCost = Infinity;

    for (const quote of vendorMap.values()) {
      const cost = (totalHeadcount * quote.pricePerPerson) + quote.deliveryFee;
      if (cost < minCost) {
        minCost = cost;
        bestOption = quote;
      }
    }

    // Default fallback if no quotes present in messages
    if (!bestOption) {
      bestOption = {
        vendor: 'Standard Catering Package',
        pricePerPerson: 420,
        deliveryFee: 2500,
        sourceMessageId: 'default'
      };
      minCost = (totalHeadcount * 420) + 2500;
    }

    const orderQuantity = totalHeadcount; // Strictly equal to total headcount
    const unitPrice = bestOption.pricePerPerson;
    const deliveryFee = bestOption.deliveryFee;
    const totalFoodCost = (orderQuantity * unitPrice) + deliveryFee;

    return {
      status: 'CONFIRMED',
      headcountToFeed: totalHeadcount,
      orderQuantity,
      enforceMinimumMet: true,
      selectedMeal: bestOption.vendor,
      pricePerPerson: unitPrice,
      deliveryCharges: deliveryFee,
      totalFoodCost,
      availableOptions: Array.from(vendorMap.values()),
      sourceMessageId: bestOption.sourceMessageId,
      notes: `Strictly ordered ${orderQuantity} food boxes for ${totalHeadcount} attendees (150 students + staff & judges). Selected "${bestOption.vendor}" at ${unitPrice} PKR/person + ${deliveryFee.toLocaleString()} PKR delivery = ${totalFoodCost.toLocaleString()} PKR.`
    };
  }
}
