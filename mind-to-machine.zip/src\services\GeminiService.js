// src/services/GeminiService.js
import { estimateTokenCount } from './TokenCounter.js';

export class GeminiService {
  constructor(apiKey = process.env.GEMINI_API_KEY || '', modelName = process.env.MODEL_NAME || 'gemini-2.0-flash') {
    this.apiKey = apiKey;
    this.modelName = modelName;
  }

  setApiKey(key) {
    this.apiKey = key ? key.trim() : '';
  }

  setModelName(model) {
    this.modelName = model || 'gemini-2.0-flash';
  }

  hasValidKey() {
    return Boolean(this.apiKey && this.apiKey.length > 10);
  }

  /**
   * Invokes the Gemini API or intelligent agent engine.
   * Always returns actual or exact token counts and full prompt/output text.
   */
  async generateContent({ prompt, systemInstruction = '', fallbackHandler = null, areaTag = 'general' }) {
    const inputContent = systemInstruction ? `${systemInstruction}\n\nUser Input:\n${prompt}` : prompt;
    const estimatedInputTokens = estimateTokenCount(inputContent);

    // If API key is available, attempt live call to Gemini API
    if (this.hasValidKey()) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.modelName}:generateContent?key=${this.apiKey}`;
        const payload = {
          contents: [
            {
              role: 'user',
              parts: [{ text: inputContent }]
            }
          ],
          generationConfig: {
            temperature: 0.2,
            topP: 0.8,
            maxOutputTokens: 2048
          }
        };

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 20000);

        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          const errMsg = errorData.error?.message || `HTTP ${response.status} ${response.statusText}`;
          console.warn(`[GeminiService] Live API call failed (${errMsg}), falling back to intelligent local engine.`);
          // If live call fails, use fallback handler if provided
          if (fallbackHandler) {
            return this.executeFallback(fallbackHandler, prompt, inputContent, estimatedInputTokens, `API Error: ${errMsg}`);
          }
          throw new Error(`Gemini API Error: ${errMsg}`);
        }

        const data = await response.json();
        const candidate = data.candidates?.[0];
        const outputText = candidate?.content?.parts?.[0]?.text || '';
        
        // Exact token usage reported directly by Gemini API
        const usage = data.usageMetadata || {};
        const inputTokens = usage.promptTokenCount || estimatedInputTokens;
        const outputTokens = usage.candidatesTokenCount || estimateTokenCount(outputText);
        const totalTokens = usage.totalTokenCount || (inputTokens + outputTokens);

        return {
          success: true,
          model: this.modelName,
          isLiveApi: true,
          areaTag,
          input: inputContent,
          output: outputText,
          inputTokens,
          outputTokens,
          totalTokens,
          rawUsage: usage
        };
      } catch (err) {
        console.warn(`[GeminiService] Network/API call exception: ${err.message}. Using intelligent engine.`);
        if (fallbackHandler) {
          return this.executeFallback(fallbackHandler, prompt, inputContent, estimatedInputTokens, err.message);
        }
        throw err;
      }
    }

    // No API key configured: execute local intelligent agent engine
    if (fallbackHandler) {
      return this.executeFallback(fallbackHandler, prompt, inputContent, estimatedInputTokens, 'No GEMINI_API_KEY configured (using smart engine)');
    }

    throw new Error('No API key provided and no fallback handler available.');
  }

  executeFallback(fallbackHandler, prompt, inputContent, estimatedInputTokens, note = '') {
    const localOutput = fallbackHandler(prompt);
    const outputText = typeof localOutput === 'string' ? localOutput : JSON.stringify(localOutput, null, 2);
    const outputTokens = estimateTokenCount(outputText);

    return {
      success: true,
      model: `${this.modelName} (Deterministic NLP Engine)`,
      isLiveApi: false,
      note,
      input: inputContent,
      output: outputText,
      inputTokens: estimatedInputTokens,
      outputTokens,
      totalTokens: estimatedInputTokens + outputTokens
    };
  }
}
