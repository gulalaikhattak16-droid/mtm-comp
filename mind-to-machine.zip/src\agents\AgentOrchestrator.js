// src/agents/AgentOrchestrator.js
import { ReadingAgent } from './ReadingAgent.js';
import { VenueAgent } from './VenueAgent.js';
import { ScheduleAgent } from './ScheduleAgent.js';
import { FoodAgent } from './FoodAgent.js';
import { JudgingAgent } from './JudgingAgent.js';
import { BudgetAgent } from './BudgetAgent.js';
import { ConflictResolver } from './ConflictResolver.js';

export class AgentOrchestrator {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;

    this.readingAgent = new ReadingAgent(geminiService, stateStore);
    this.venueAgent = new VenueAgent(geminiService, stateStore);
    this.scheduleAgent = new ScheduleAgent(geminiService, stateStore);
    this.foodAgent = new FoodAgent(geminiService, stateStore);
    this.judgingAgent = new JudgingAgent(geminiService, stateStore);
    this.budgetAgent = new BudgetAgent(geminiService, stateStore);
    this.conflictResolver = new ConflictResolver(stateStore);
  }

  /**
   * Initial batch run: Processes all parsed messages and generates complete 5-area plan.
   */
  async processAllMessages(messages) {
    // Save messages in store
    messages.forEach(m => this.stateStore.addMessage(m));

    // 1. Reading Agent
    const { facts } = await this.readingAgent.processMessages(messages);
    this.stateStore.facts = facts;

    // 2. Derive Event Parameters
    let participants = 150;
    let teams = 50;
    let organizers = 12;
    let approvedBudget = 350000;

    facts.forEach(f => {
      if (f.category === 'metadata' && f.details) {
        if (f.details.participants) participants = f.details.participants;
        if (f.details.teams) teams = f.details.teams;
        if (f.details.organizers) organizers = f.details.organizers;
        if (f.details.budgetLimit) approvedBudget = f.details.budgetLimit;
      }
    });

    // Update metadata in store
    this.stateStore.metadata = {
      eventName: 'Mind to Machine Hackathon',
      location: 'Islamabad',
      targetParticipants: participants,
      targetTeams: teams,
      organizersCount: organizers,
      targetDurationHours: 4,
      totalHeadcount: participants + organizers + 5 // initially assume 5 judges
    };

    const targetHeadcount = this.stateStore.metadata.totalHeadcount;

    // 3. Parallel or sequential agent execution
    // Venue Agent
    const venuePlan = await this.venueAgent.evaluate(facts, targetHeadcount);

    // Schedule Agent
    const schedulePlan = await this.scheduleAgent.buildSchedule(facts, this.stateStore.metadata);

    // Judging Agent (determines judges count and honorarium)
    const judgingPlan = await this.judgingAgent.calculate(facts, teams);

    // Recalculate exact total headcount with confirmed judges count
    const confirmedJudges = judgingPlan.availableJudges || 5;
    const finalHeadcount = participants + organizers + confirmedJudges;
    this.stateStore.metadata.totalHeadcount = finalHeadcount;

    // Food Agent (uses final headcount)
    const foodPlan = await this.foodAgent.calculate(facts, finalHeadcount);

    // Budget Agent (aggregates venue, food, judging, prizes, tech, etc.)
    const budgetPlan = await this.budgetAgent.validateBudget(facts, {
      venue: venuePlan,
      food: foodPlan,
      judging: judgingPlan
    });

    // Determine overall validity
    this.updateOverallValidity();

    return this.stateStore.getStateSummary();
  }

  /**
   * Dynamic Update: Handles a single new message.
   * Constraint: Uses <= 5 model calls. Calls ONLY affected agents.
   */
  async processNewMessage(newMessage) {
    this.stateStore.addMessage(newMessage);

    // Call 1: Reading Agent extracts facts from this specific new message
    const { facts: newFacts } = await this.readingAgent.processMessages([newMessage]);
    
    // Evaluate proposal against current plan and constraints
    const evaluation = this.conflictResolver.evaluateProposal(
      newMessage,
      newFacts,
      this.stateStore.plan,
      this.stateStore.metadata
    );

    if (!evaluation.isAccepted) {
      newMessage.status = 'rejected';
      newMessage.validationReason = evaluation.reason;
      return {
        success: false,
        accepted: false,
        modelCallsUsed: 1,
        message: evaluation.reason,
        affectedAreas: [],
        state: this.stateStore.getStateSummary()
      };
    }

    // Merge new facts into existing facts
    newFacts.forEach(nf => this.stateStore.facts.push(nf));
    newMessage.status = 'processed';
    newMessage.validationReason = evaluation.reason;

    const affected = evaluation.affectedAreas;
    let modelCallsUsed = 1; // Reading agent was call 1

    // Conditionally invoke only affected agents (max 4 additional calls -> total <= 5)
    if (affected.includes('venue') && modelCallsUsed < 5) {
      await this.venueAgent.evaluate(this.stateStore.facts, this.stateStore.metadata.totalHeadcount);
      modelCallsUsed++;
    }

    if (affected.includes('schedule') && modelCallsUsed < 5) {
      await this.scheduleAgent.buildSchedule(this.stateStore.facts, this.stateStore.metadata);
      modelCallsUsed++;
    }

    if (affected.includes('judging') && modelCallsUsed < 5) {
      await this.judgingAgent.calculate(this.stateStore.facts, this.stateStore.metadata.targetTeams);
      modelCallsUsed++;
      
      // Update headcount if judges changed
      const judges = this.stateStore.plan.judging?.availableJudges || 5;
      this.stateStore.metadata.totalHeadcount = this.stateStore.metadata.targetParticipants + this.stateStore.metadata.organizersCount + judges;
      affected.push('food'); // food headcount might need re-check
    }

    if (affected.includes('food') && modelCallsUsed < 5) {
      await this.foodAgent.calculate(this.stateStore.facts, this.stateStore.metadata.totalHeadcount);
      modelCallsUsed++;
    }

    if (affected.includes('budget') && modelCallsUsed < 5) {
      await this.budgetAgent.validateBudget(this.stateStore.facts, this.stateStore.plan);
      modelCallsUsed++;
    }

    this.updateOverallValidity();

    return {
      success: true,
      accepted: true,
      modelCallsUsed,
      affectedAreas: affected,
      message: `Plan dynamically updated. Affected areas: ${affected.join(', ') || 'None'}. (Model calls used: ${modelCallsUsed})`,
      state: this.stateStore.getStateSummary()
    };
  }

  updateOverallValidity() {
    const p = this.stateStore.plan;
    const errors = [];
    const warnings = [];

    // Check venue
    if (!p.venue.recommended) {
      errors.push('No valid venue selected that satisfies capacity and generator requirements.');
    }

    // Check budget
    if (p.budget.totalExpenditure > p.budget.totalApprovedBudget) {
      errors.push(`Budget exceeded! Expenditure (${p.budget.totalExpenditure.toLocaleString()} PKR) > Approved (${p.budget.totalApprovedBudget.toLocaleString()} PKR).`);
    }

    // Check food minimum
    if (p.food.orderQuantity < p.food.headcountToFeed) {
      errors.push(`Food order quantity (${p.food.orderQuantity}) is lower than headcount (${p.food.headcountToFeed}).`);
    }

    // Check judging sufficiency
    if (!p.judging.isCapacitySufficient) {
      warnings.push(`Judging capacity alert: ${p.judging.availableJudges} judges available, but ${p.judging.requiredJudges} needed for 50 teams.`);
    }

    const isValid = errors.length === 0;

    this.stateStore.overallValidity = {
      isValid,
      status: isValid ? (warnings.length > 0 ? 'VALID_WITH_WARNINGS' : 'FULLY_VALID') : 'INVALID',
      errors,
      warnings,
      lastUpdated: new Date().toISOString()
    };
  }
}
