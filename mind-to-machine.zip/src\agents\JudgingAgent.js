// src/agents/JudgingAgent.js

export class JudgingAgent {
  constructor(geminiService, stateStore) {
    this.geminiService = geminiService;
    this.stateStore = stateStore;
  }

  async calculate(facts, totalTeams = 50) {
    const judgingFacts = facts.filter(f => f.category === 'judging');
    const promptText = `Calculate judging capacity and allocation for Mind to Machine Hackathon.
Number of teams: ${totalTeams}.
Calculate:
1. Required number of judges given team count, demo duration per team, max teams per judge, and judging window.
2. Team allocation distribution per judge.
3. Total honorarium.
4. Sufficiency verdict.

Judging Facts:
${JSON.stringify(judgingFacts, null, 2)}
`;

    const systemInstruction = `You are the Judging & Evaluation Agent. Compute judge requirements, load distribution, and adequacy. Return valid JSON.`;

    const result = await this.geminiService.generateContent({
      prompt: promptText,
      systemInstruction,
      areaTag: 'judging',
      fallbackHandler: () => this.calculateDeterministic(judgingFacts, totalTeams)
    });

    let judgingPlan = null;
    try {
      const cleanJson = result.output.replace(/```json/g, '').replace(/```/g, '').trim();
      judgingPlan = JSON.parse(cleanJson);
    } catch {
      judgingPlan = this.calculateDeterministic(judgingFacts, totalTeams);
    }

    // Record trace
    this.stateStore.recordTrace({
      model: result.model,
      areaTag: 'judging',
      input: result.input,
      output: result.output,
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      totalTokens: result.totalTokens,
      isLiveApi: result.isLiveApi,
      note: result.note
    });

    this.stateStore.plan.judging = judgingPlan;
    return judgingPlan;
  }

  calculateDeterministic(judgingFacts, totalTeams = 50) {
    let confirmedCount = 0;
    let honorariumPerJudge = 5000;
    let timePerTeam = 5; // minutes
    let maxTeamsPerJudge = 10;
    let judgingWindowMinutes = 45; // minutes
    let judgeList = [];

    judgingFacts.forEach(jf => {
      const d = jf.details || {};
      if (d.confirmedCount) confirmedCount = d.confirmedCount;
      if (d.honorarium) honorariumPerJudge = d.honorarium;
      if (d.timePerTeam) timePerTeam = d.timePerTeam;
      if (d.maxTeamsPerJudge) maxTeamsPerJudge = d.maxTeamsPerJudge;
      if (d.judgingWindowMinutes) judgingWindowMinutes = d.judgingWindowMinutes;
      if (d.judgeNames && d.judgeNames.length > 0) {
        judgeList = d.judgeNames;
        if (!confirmedCount) confirmedCount = judgeList.length;
      }
    });

    // If no names were extracted, provide placeholder list based on count
    if (judgeList.length === 0 && confirmedCount > 0) {
      for (let i = 1; i <= confirmedCount; i++) {
        judgeList.push(`Judge ${i} (Industry Expert)`);
      }
    } else if (confirmedCount === 0) {
      confirmedCount = 5; // Default required minimum
      judgeList = [
        'Dr. Farhan (AI Researcher)',
        'Engr. Bilal (Cloud Architect)',
        'Ms. Zainab (VP Product)',
        'Mr. Tariq (Senior Tech Lead)',
        'Ms. Maria (ML Engineer)'
      ];
    }

    // Capacity per judge: either explicit maxTeamsPerJudge or judgingWindow / timePerTeam
    const capacityPerJudge = maxTeamsPerJudge || (Math.floor(judgingWindowMinutes / timePerTeam) || 10);
    const requiredJudges = Math.ceil(totalTeams / capacityPerJudge);
    const isSufficient = confirmedCount >= requiredJudges;

    // Team allocation
    const allocation = [];
    const teamsPerActiveJudge = Math.ceil(totalTeams / confirmedCount);
    let startTeam = 1;

    for (let i = 0; i < confirmedCount; i++) {
      const endTeam = Math.min(totalTeams, startTeam + teamsPerActiveJudge - 1);
      const teamCount = Math.max(0, endTeam - startTeam + 1);
      
      allocation.push({
        judgeNumber: i + 1,
        judgeName: judgeList[i] || `Judge ${i + 1}`,
        assignedTeamRange: `Teams ${startTeam} - ${endTeam}`,
        assignedTeamCount: teamCount,
        estimatedTimeMinutes: teamCount * timePerTeam
      });

      startTeam = endTeam + 1;
      if (startTeam > totalTeams) break;
    }

    const totalHonorarium = confirmedCount * honorariumPerJudge;

    let explanation = '';
    if (isSufficient) {
      explanation = `Sufficient judging capacity: With ${confirmedCount} confirmed judges, each judge evaluates ${teamsPerActiveJudge} teams (within the limit of ${maxTeamsPerJudge} teams per judge). Total 50 teams will be evaluated in parallel within the judging session.`;
    } else {
      explanation = `INSUFFICIENT JUDGING CAPACITY ALERT: ${confirmedCount} judges are available, but ${requiredJudges} judges are required to evaluate 50 teams at ${timePerTeam} mins/team without exceeding ${maxTeamsPerJudge} teams per judge. Please recruit ${requiredJudges - confirmedCount} additional judge(s).`;
    }

    return {
      status: isSufficient ? 'CONFIRMED' : 'CAPACITY_WARNING',
      totalTeams,
      timeRequiredPerTeam: timePerTeam,
      maxTeamsPerJudge,
      availableJudgingTime: judgingWindowMinutes,
      requiredJudges,
      availableJudges: confirmedCount,
      isCapacitySufficient: isSufficient,
      judgeList,
      honorariumPerJudge,
      totalHonorarium,
      allocation,
      explanation
    };
  }
}
